package clases;

public class usuario {
	private String usuarios;
	private String Nombre;
	private String Contrase�a;
	 private String Departamento;
	 
	public usuario(String usuarios, String Nombre, String Contrase�a, String Departamento) {
		
		this.usuarios=usuarios;
		this.Nombre=Nombre;
		this.Contrase�a=Contrase�a;
		this.Departamento=Departamento;
		// TODO Auto-generated constructor stub
	}
	public usuario() {
		// TODO Auto-generated constructor stub
	}
	public String getUsuarios() {
		return usuarios;
	}
	public void setUsuarios(String usuarios) {
		this.usuarios = usuarios;
	}
	
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public String getContrase�a() {
		return Contrase�a;
	}
	public void setContrase�a(String contrase�a) {
		Contrase�a = contrase�a;
	}
	public String getDepartamento() {
		return Departamento;
	}
	public void setDepartamento(String departamento) {
		Departamento = departamento;
	}
}
		