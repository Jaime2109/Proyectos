import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import Logistica.Logistica;
import Produccion.Almacen;
import direccion_finanzas.Finanzas;
import formulario.Dgeneral;
import recursos_humanos.rrhh;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JProgressBar;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DropMode;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import javax.swing.border.MatteBorder;
import java.awt.SystemColor;

public class login extends JFrame {

	private JPanel  contentPane;
	private JTextField txtUsuario;
	private JTextField txtpass;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login frame = new login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public login() {
		setTitle("Usuario");
		setBackground(Color.WHITE);
		setFont(new Font("Baskerville Old Face", Font.BOLD | Font.ITALIC, 12));
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\jaime\\Desktop\\FabricaAutoPartes\\res\\AutoPartes.jpg"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 672, 300);
		 contentPane = new JPanel();
		 contentPane.setBackground(SystemColor.window);
		 contentPane.setForeground(Color.BLACK);
		 contentPane.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		setContentPane( contentPane);
		 contentPane.setLayout(null);
		
		
		txtUsuario = new JTextField();
		txtUsuario.setBounds(428, 61, 187, 25);
		 contentPane.add(txtUsuario);
		txtUsuario.setColumns(10);
		 
		 txtpass = new JPasswordField();
		 txtpass.setBounds(428, 132, 187, 25);
		 contentPane.add(txtpass);
		 
		 
		JLabel pasword = new JLabel("Usuario:");
		pasword.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 25));
		pasword.setBounds(259, 58, 120, 33);
		 contentPane.add(pasword);
		
		JLabel lblNewLabel = new JLabel("Contrase\u00F1a:");
		lblNewLabel.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 25));
		lblNewLabel.setBounds(255, 124, 149, 33);
		 contentPane.add(lblNewLabel);
		
		JButton ingresar = new JButton("Ingresar");
		ingresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String clave= txtUsuario.getText();
				String usuario = txtpass.getText();
				
////////////////LOGIN PARA DEPARTAMENTOS////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				
				if(txtUsuario.getText().equals("Direccion") && txtpass.getText().equals("Direccion")) {
					
					dispose();
					JOptionPane.showMessageDialog(null, "Bienvenido al Sistema", "Acceso Correcto", JOptionPane.INFORMATION_MESSAGE);
					Dgeneral p = new Dgeneral();
					p.setVisible(true);
					
				}else if (txtUsuario.getText().equals("Finanzas") && usuario.equals("Finanzas")){
					
					dispose();
					JOptionPane.showMessageDialog(null, "Bienvenido al Sistema", "Acceso Correcto", JOptionPane.INFORMATION_MESSAGE);
					Finanzas f = new Finanzas();
					f.setVisible(true);
					
				}else if (txtUsuario.getText().equals("RRHH") && clave.equals("RRHH")){
					
					dispose();
					JOptionPane.showMessageDialog(null, "Bienvenido al Sistema", "Acceso Correcto", JOptionPane.INFORMATION_MESSAGE);
					rrhh rh = new rrhh();
					rh.setVisible(true);
					
				}else if (txtUsuario.getText().equals("Logistica") && clave.equals("Logistica")){
					
					dispose();
					JOptionPane.showMessageDialog(null, "Bienvenido al Sistema", "Acceso Correcto", JOptionPane.INFORMATION_MESSAGE);
		        	Logistica l = new Logistica();
					l.setVisible(true);
					
				}else if (txtUsuario.getText().equals("Almacen") && clave.equals("Almacen")){
					
					dispose();
					JOptionPane.showMessageDialog(null, "Bienvenido al Sistema", "Acceso Correcto", JOptionPane.INFORMATION_MESSAGE);
					Almacen frame = new Almacen();
					frame.setVisible(true);
					
				}/*else if (txtUsuario.getText().equals("Comercial") && clave.equals("Comercial")){
					
					dispose();
					JOptionPane.showMessageDialog(null, "Bienvenido al Sistema", "Acceso Correcto", JOptionPane.INFORMATION_MESSAGE);
					// clasedepartamento nombre_objeto = new clasedepartamento
					// nombre_objeto.setVisible(true);
					
				}else if (txtUsuario.getText().equals("TI") && clave.equals("TI")){
					
					dispose();
					JOptionPane.showMessageDialog(null, "Bienvenido al Sistema", "Acceso Correcto", JOptionPane.INFORMATION_MESSAGE);
					// clasedepartamento nombre_objeto = new clasedepartamento
					// nombre_objeto.setVisible(true);
					
				}*/else {
					JOptionPane.showMessageDialog(null, "Ususario o Contrase�a Incorrectos", "Denied", JOptionPane.INFORMATION_MESSAGE);
				}
				
			}
		});
		ingresar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		ingresar.setBounds(502, 227, 113, 23);
		ingresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		 contentPane.add(ingresar);
		
		JButton salir = new JButton("Salir");
		salir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				salir();
			}


			private void salir() {
				System.exit(0);
				
			}
		});
	
	
		salir.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		salir.setBounds(66, 227, 113, 23);
		salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		 contentPane.add(salir);
		 
		 JLabel lblNewLabel_1 = new JLabel("");
		 lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\jaime\\Desktop\\FabricaAutoPartes\\res\\icono-user.png"));
		 lblNewLabel_1.setBounds(66, 11, 120, 195);
		 contentPane.add(lblNewLabel_1);
		 

		JButton btnRegresar = new JButton("Regresar");
		btnRegresar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnRegresar.setBounds(373, 227, 119, 23);
		contentPane.add(btnRegresar);
		btnRegresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnRegresar.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			regresar();
		}
		private void regresar() {
			setVisible(false);				
		}
		});
	}
}

	
		 

