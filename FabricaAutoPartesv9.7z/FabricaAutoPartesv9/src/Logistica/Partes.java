package Logistica;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.SystemColor;

import javax.swing.JEditorPane;



import utils.MySQLConexion;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Partes extends JFrame {
	
	
	private void eliminar() {
		 txtidpieza.setText(null);
	      txtcantidad.setText(null);
	      txtserie.setText(null);
	      txtcosto.setText(null);
	}

	    
	public static Connection getconexion() {
	Connection con =null;

   
   try {
       Class.forName("com.mysql.jdbc.Driver");
     String url = "jdbc:mysql://localhost:3306/cartas_1";
     String usr ="root";
     String psw = "James1509";
     
     PreparedStatement ps;
     ResultSet rs;
     
     con = DriverManager.getConnection(url,usr,psw);
  

   } catch (ClassNotFoundException e) {
       System.out.println("Error al cargar el controlador");
     

   } catch (SQLException e) {
       System.out.println("Error en la conexi�n a base de datos");
   }
   
   return con;
}

private void limpiarcajas() {
	
	txtidpieza.setText(null);
	 txtcantidad.setText(null);
	  txtserie.setText(null);
	  txtcosto.setText(null);
	
}
	private JPanel contentPane;
	private JTextField txtidpieza;
	private JTextField txtcantidad;
	private JTextField txtserie;
	private JTextField txtcosto;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Partes frame = new Partes();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Partes() {
		setTitle("Logistica");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 525, 300);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtidpieza = new JTextField();
		txtidpieza.setBounds(225, 52, 96, 19);
		contentPane.add(txtidpieza);
		txtidpieza.setColumns(10);
		
		txtcantidad = new JTextField();
		txtcantidad.setBounds(225, 96, 96, 19);
		contentPane.add(txtcantidad);
		txtcantidad.setColumns(10);
		
		txtserie = new JTextField();
		txtserie.setBounds(225, 138, 96, 19);
		contentPane.add(txtserie);
		txtserie.setColumns(10);
		
		txtcosto = new JTextField();
		txtcosto.setBounds(225, 180, 96, 19);
		contentPane.add(txtcosto);
		txtcosto.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Nombre de la pieza");
		lblNewLabel.setBounds(28, 55, 141, 13);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Cantidad de almacen");
		lblNewLabel_1.setBounds(28, 99, 141, 13);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Serie de la pieza");
		lblNewLabel_2.setBounds(28, 142, 127, 13);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Costo");
		lblNewLabel_3.setBounds(28, 184, 127, 13);
		contentPane.add(lblNewLabel_3);
		
		
		JButton btnNewButton_1 = new JButton("Buscar");
		btnNewButton_1.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		 btnNewButton_1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnNewButton_1.setBounds(28, 229, 141, 21);
			btnNewButton_1.addActionListener(new ActionListener() {
			
				private PreparedStatement ps;
				private ResultSet rs;

				
				public void actionPerformed(ActionEvent e) {
					Connection con = null;
					try {
	                    con = MySQLConexion.getconexion();
						
						
						ps= con.prepareStatement("SELECT * FROM partes WHERE idpieza=?");
						ps.setString(1,txtidpieza.getText());
				      
				      
						
						rs = ps.executeQuery();
						
						if(rs.next()) {
							 txtidpieza.setText(rs.getString("idpieza"));
						      txtcantidad.setText(rs.getString("cantidad")); 
						      txtserie.setText(rs.getString("serie"));
						      txtcosto.setText(rs.getString("costo"));
						     
						     
						      
						
				    	
					}else {
						JOptionPane.showMessageDialog(null,"producto no existente");
						limpiarcajas();
					}
			    	
				}catch(Exception e1) {

					System.err.println(e1);
				
				}
			}
		});
		
		contentPane.add(btnNewButton_1);
		

		JButton btnRegresar = new JButton("Regresar");
		btnRegresar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		 btnRegresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnRegresar.setBounds(359, 228, 141, 23);
		contentPane.add(btnRegresar);
		btnRegresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 regresar();
			}
			
			private void regresar() {
				setVisible(false);
				
			}
		});
		
		JButton btnNewButton = new JButton("Limpiar");
		btnNewButton.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnNewButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnNewButton.setBounds(192, 229, 141, 21);
		btnNewButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				  limpiarcajas();
			}
			
				
					    	
		});
				
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon("C:\\Users\\jaime\\Desktop\\FabricaAutoPartesv8\\res\\Logov.jpg"));
		lblNewLabel_4.setBounds(359, 55, 141, 144);
		contentPane.add(lblNewLabel_4);
	}

}