package Logistica;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import utils.MySQLConexion;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.SystemColor;

import javax.swing.JEditorPane;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class Logistica extends JFrame {
	JFileChooser seleccionar = new JFileChooser ();
    File Archivo;
    FileInputStream entrada;
    FileOutputStream salida;
    
	private void eliminar() {
	
	      txtidfolio.setText(null);
	      txtcertificado.setText(null);
	      txtcertificados.setText(null);
	      txtfolios.setText(null);
	      txtfecha.setText(null);
	      txtcomprobante.setText(null);
	      txtrfc.setText(null);
	      txtnombre.setText(null);
	      txtnumeroc.setText(null);
	      txtpedido.setText(null);
	}
	private void limpiarcajas() {
		
	      txtidfolio.setText(null);
	      txtcertificado.setText(null);
	      txtcertificados.setText(null);
	      txtfolios.setText(null);
	      txtfecha.setText(null);
	      txtcomprobante.setText(null);
	      txtnombre.setText(null);
	      txtrfc.setText(null);
	      txtnumeroc.setText(null);
	      txtpedido.setText(null);
	}
	public static Connection getconexion() {
	Connection con =null;

   
   try {
       Class.forName("com.mysql.jdbc.Driver");
     String url = "jdbc:mysql://localhost:3306/cartas_1";
     String usr ="root";
     String psw = "James1509";
     
     PreparedStatement ps;
     ResultSet rs;
     
     con = DriverManager.getConnection(url,usr,psw);
  

   } catch (ClassNotFoundException e) {
       System.out.println("Error al cargar el controlador");
     

   } catch (SQLException e) {
       System.out.println("Error en la conexi�n a base de datos");
   }
   
   return con;
}


    

	private JPanel contentPane;

	private JTextField txtidfolio;
	private JTextField txtcertificado;
	private JTextField txtcertificados;
	private JTextField txtfolios;
	private JTextField txtfecha;
	private JTextField txtcomprobante;
	private JTextField txtrfc;
	private JTextField txtnombre;
	private JTextField txtnumeroc;
	private JTable table;
	private JTextField txtpedido;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Logistica frame = new Logistica();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Logistica() {
		setTitle("Logistica");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 834, 714);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Folio");
		lblNewLabel.setBounds(528, 24, 45, 16);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Certificado SAT");
		lblNewLabel_1.setBounds(528, 117, 88, 13);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Certificado CSD");
		lblNewLabel_2.setBounds(528, 67, 104, 13);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Folio SAT");
		lblNewLabel_3.setBounds(528, 162, 88, 13);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Fecha de emision");
		lblNewLabel_4.setBounds(528, 212, 128, 13);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Comprobante");
		lblNewLabel_5.setBounds(528, 263, 122, 13);
		contentPane.add(lblNewLabel_5);
		
		txtidfolio = new JTextField();
		txtidfolio.setBounds(642, 22, 147, 19);
		contentPane.add(txtidfolio);
		txtidfolio.setColumns(10);
		
		txtcertificado = new JTextField();
		txtcertificado.setBounds(642, 63, 147, 19);
		contentPane.add(txtcertificado);
		txtcertificado.setColumns(10);
		
		txtcertificados = new JTextField();
		txtcertificados.setBounds(642, 113, 147, 19);
		contentPane.add(txtcertificados);
		txtcertificados.setColumns(10);
		
		txtfolios = new JTextField();
		txtfolios.setBounds(642, 158, 147, 19);
		contentPane.add(txtfolios);
		txtfolios.setColumns(10);
		
		txtfecha= new JTextField();
		txtfecha.setBounds(642, 208, 147, 19);
		contentPane.add(txtfecha);
		txtfecha.setColumns(10);
		
		txtcomprobante = new JTextField();
		txtcomprobante.setBounds(642, 259, 147, 19);
		contentPane.add(txtcomprobante);
		txtcomprobante.setColumns(10);
		
	
		
		
		JLabel lblNewLabel_7 = new JLabel("Receptor");
		lblNewLabel_7.setForeground(SystemColor.desktop);
		lblNewLabel_7.setBounds(10, 384, 111, 13);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("RFC");
		lblNewLabel_8.setBounds(10, 408, 45, 13);
		contentPane.add(lblNewLabel_8);
		

		txtrfc = new JTextField();

		txtrfc.setBounds(146, 405, 252, 19);
		contentPane.add(txtrfc);
		txtrfc.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("Nombre");
		lblNewLabel_9.setBounds(10, 446, 45, 13);
		contentPane.add(lblNewLabel_9);
		
		txtnombre = new JTextField();
		txtnombre.setBounds(146, 443, 252, 19);
		contentPane.add(txtnombre);
		txtnombre.setColumns(10);
		
		JLabel lblNewLabel_10 = new JLabel("Numero de Cliente");
		lblNewLabel_10.setBounds(10, 493, 111, 13);
		contentPane.add(lblNewLabel_10);
		
		JTextPane txtpnNotaParaLos = new JTextPane();
		txtpnNotaParaLos.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtpnNotaParaLos.setText("Nota Para Los Departamentos:");
		txtpnNotaParaLos.setBounds(10, 540, 785, 83);
		contentPane.add(txtpnNotaParaLos);
		
		JButton btnNewButton = new JButton("Buscar Folio");
		btnNewButton.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnNewButton.setBounds(544, 488, 128, 21);
		btnNewButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		contentPane.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				PreparedStatement ps;
				ResultSet rs;

				
					Connection con = null;
					
					try {
	                    con = MySQLConexion.getconexion();
						
						
						ps= con.prepareStatement("SELECT * FROM logistica WHERE idfolio =?");
						ps.setString(1,txtidfolio.getText());
				      
				      
						
						rs = ps.executeQuery();
						
						if(rs.next()) {
							 txtidfolio.setText(rs.getString("idfolio"));
						      txtcertificado.setText(rs.getString("certificado")); 
						      txtcertificados.setText(rs.getString("certificados"));
						      txtfolios.setText(rs.getString("folios"));
						      txtfecha.setText(rs.getString("fecha"));
						      txtcomprobante.setText(rs.getString("comprobante"));
						      txtrfc.setText(rs.getString("rfc"));
						      txtnombre.setText(rs.getString("nombre"));
						      txtnumeroc.setText(rs.getString("numeroc"));
						      txtpedido.setText(rs.getString("pedido"));
						     
						      
						}else {
							JOptionPane.showMessageDialog(null,"Nota no existente");
							
						}
				    	
					}catch(Exception e1) {

						System.err.println(e1);
					
					}
			}
		
		});


		
		txtpedido = new JTextField();
		txtpedido.setBounds(146, 490, 252, 19);
		contentPane.add(txtpedido);
		txtpedido.setColumns(10);
		
		table = new JTable();
		table.setBounds(486, 562, -356, -53);
		contentPane.add(table);
		
		JLabel lblNewLabel_11 = new JLabel("Numero de pedido");
		lblNewLabel_11.setBounds(418, 394, 116, 40);
		contentPane.add(lblNewLabel_11);
		
		txtnumeroc = new JTextField();
		txtnumeroc.setBounds(544, 404, 196, 19);
		contentPane.add(txtnumeroc);
		txtnumeroc.setColumns(10);
		
		
	
		JButton btnNewButton_1 = new JButton("Agregar Folio");
		btnNewButton_1.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_1.setBounds(544, 441, 128, 21);
		btnNewButton_1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		contentPane.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			Connection con;
			PreparedStatement ps;
			
			
				
				Connection con1 = null;
			
				try {
					
					con1 = MySQLConexion.getconexion();
					
					
					ps= con1.prepareStatement("INSERT INTO logistica(idfolio, certificado, certificados, folios, fecha, comprobante, rfc, nombre, numeroc, pedido ) VALUES( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			      
			        
			        ps.setString(1,txtidfolio.getText());
			        ps.setString(2,txtcertificado.getText());
			        ps.setString(3,txtcertificados.getText());
			        ps.setString(4,txtfolios.getText());
			        ps.setString(5,txtfecha.getText());
			        ps.setString(6,txtcomprobante.getText());
			        ps.setString(7,txtrfc.getText());
			        ps.setString(8,txtnombre.getText());
			        ps.setString(9,txtnumeroc.getText());
			        ps.setString(10,txtpedido.getText());
			    	
			     
					int rs = ps.executeUpdate();

					if (rs > 0) {
						JOptionPane.showMessageDialog(null,"Nota Nueva Agregada ");
						eliminar();
					}else {
						JOptionPane.showMessageDialog(null,"Error Al Introducir Nota Nuev");
						eliminar();
					}
					
					con1.close();
					
				
				}catch(Exception e1) {

					System.err.println(e1);
				
				}
			
	}
});
		
		JButton btnNewButton_2 = new JButton("Buscar Pieza");
		btnNewButton_2.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Partes frame = new Partes();
				frame.setVisible(true);
			}
		});
		btnNewButton_2.setBounds(682, 488, 128, 21);
		contentPane.add(btnNewButton_2);
		
		JLabel txtnotas = new JLabel("Notas");
		txtnotas.setForeground(SystemColor.activeCaptionText);
		txtnotas.setBounds(10, 516, 45, 13);
		contentPane.add(txtnotas);
		
		JButton btnRegresar = new JButton("Regresar");
		btnRegresar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnRegresar.setBounds(676, 634, 119, 23);
		contentPane.add(btnRegresar);
		btnRegresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		
		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setIcon(new ImageIcon("C:\\Users\\jaime\\Desktop\\FabricaAutoPartesv8\\res\\AutoPartes.jpg"));
		lblNewLabel_6.setBounds(10, 22, 511, 336);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_14 = new JLabel("");
		lblNewLabel_14.setIcon(new ImageIcon("C:\\Users\\jaime\\Desktop\\FabricaAutoPartesv8\\res\\icono-user.png"));
		lblNewLabel_14.setBounds(408, 446, 128, 84);
		contentPane.add(lblNewLabel_14);
		
		JButton btnNewButton_1_1 = new JButton("Limpiar");
		btnNewButton_1_1.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_1_1.setBounds(682, 441, 128, 21);
		btnNewButton_1_1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnNewButton_1_1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				  limpiarcajas();
			}
			
				
					    	
		});
		
		contentPane.add(btnNewButton_1_1);
		
		JButton btnNewButton_2_1 = new JButton("Guardar Nota");
		btnNewButton_2_1.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_2_1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(seleccionar.showDialog(null,"Guardar Nota")==JFileChooser.APPROVE_OPTION) {
					Archivo=seleccionar.getSelectedFile();
						if(Archivo.getName().endsWith("txt")) {
							String Documento=txtpnNotaParaLos.getText();
							String Mensaje=GuardarArchivo(Archivo,Documento);
								if(Mensaje!=null) {
									JOptionPane.showMessageDialog(null, Mensaje);
									}else {
									JOptionPane.showMessageDialog(null,"Archivo No Compatible");
									}
						}else {
							JOptionPane.showMessageDialog(null, "Guardar Documento De Texto");
						}
			}
			}

			private String GuardarArchivo(File archivo, String documento) {
				String mensaje=null;
				try {
					salida=new FileOutputStream(Archivo);
					byte[] bytxt=documento.getBytes();
					salida.write(bytxt);
					mensaje="Archivo Guardado";
				}catch (Exception e) {
			}
			return mensaje;
			}
		});
		btnNewButton_2_1.setBounds(10, 634, 128, 21);
		contentPane.add(btnNewButton_2_1);
		
		JButton btnNewButton_2_2 = new JButton("Abrir Nota");
		btnNewButton_2_2.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_2_2.setBounds(196, 635, 128, 21);
		btnNewButton_2_2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnNewButton_2_2.addActionListener(new ActionListener() {
			

			public void actionPerformed(ActionEvent e) {
				
				if(seleccionar.showDialog(null,"Abrir Archivo")==JFileChooser.APPROVE_OPTION) {
					Archivo=seleccionar.getSelectedFile();
					if(Archivo.canRead()) {
						if(Archivo.getName().endsWith("txt")) {
							String Documento=AbrirArchivo(Archivo);
							txtpnNotaParaLos.setText(Documento);
							
						}else {
							JOptionPane.showMessageDialog(null,"Archivo no Compatible");
						}
					}
				}
			}

			private String AbrirArchivo(File archivo) {
				String Documento="";
				
				try{
					entrada=new FileInputStream(Archivo);
					int ascci;
					while((ascci=entrada.read())!=-1) {
						char caracter = (char) ascci;
						Documento+=caracter;
					}
					} catch (Exception e) {
						
				}
				return Documento;
			}
				
		});
		contentPane.add(btnNewButton_2_2);
		btnRegresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 regresar();
			}
			
			private void regresar() {
				setVisible(false);
				
			}
		});
	}
}


