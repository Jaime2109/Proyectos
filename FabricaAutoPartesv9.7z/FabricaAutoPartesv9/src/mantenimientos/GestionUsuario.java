package mantenimientos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import clases.usuario;
import utils.MySQLConexion;

public class GestionUsuario {

	
	public usuario obtenerUsuario(usuario usu){
	 usuario usuario = null;
		
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		
		try {
		
			con = MySQLConexion.getconexion();
		
			String sql = "select*from login where Nombre = ? and Contrase�a =  ? ";
			
			pst = con.prepareStatement(sql);
			
			pst.setString(1,usu.getNombre());
			pst.setString(2,usu.getContrase�a());
			
			rs = pst.executeQuery();
			
			while (rs.next()) {
				usuario = new usuario(rs.getNString(1),rs.getNString(2),rs.getNString(3),rs.getNString(4));
				
				
			}
			
			
			
		} catch (Exception e) {
		System.out.println("Error en obtener usuario");
		}
		
		
		return usuario;
		
	}

}
