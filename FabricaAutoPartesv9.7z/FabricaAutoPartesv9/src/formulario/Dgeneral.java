package formulario;

import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextPane;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.awt.event.ActionEvent;
import java.awt.Font;


import javax.swing.ImageIcon;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.AbstractListModel;
import java.awt.Toolkit;
import javax.swing.border.MatteBorder;

import Logistica.Partes;
import direccion_finanzas.Contratos;
import direccion_finanzas.Departamentos;
import direccion_finanzas.Juntas;
import direccion_finanzas.Patrocinadores;

import java.awt.Color;
import java.awt.SystemColor;


public class Dgeneral extends JFrame {
	/**
	 * 
	 */
	public static final long serialVersionUID = 1L;
	JFileChooser seleccionar = new JFileChooser ();
    File Archivo;
    FileInputStream entrada;
    FileOutputStream salida;
	public JPanel contentPane;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Dgeneral frame = new Dgeneral();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Dgeneral() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\jaime\\Desktop\\FabricaAutoPartes\\res\\AutoPartes.jpg"));
		
		setTitle("Direcci�n General");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 676, 376);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		ImageIcon image = new ImageIcon(getClass().getClassLoader().getResource("icono-user.png"));
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\jaime\\Desktop\\FabricaAutoPartes\\res\\icono-user.png"));
		lblNewLabel.setBounds(10, 0, 119, 84);
		contentPane.add(lblNewLabel);
		
		JButton supervicion = new JButton("Supervision");
		supervicion.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		supervicion.setBounds(10, 122, 119, 23);
		supervicion.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			Departamentos frame = new  Departamentos();
			frame.setVisible(true);
		}
		});
	
		contentPane.add(supervicion);
		supervicion.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		
		JButton junta = new JButton("Juntas");
		junta.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		junta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Juntas frame = new Juntas();
				frame.setVisible(true);
			}
			});
		
		junta.setBounds(10, 166, 119, 23);
		contentPane.add(junta);
		junta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		
		JButton negocio = new JButton("Contratos");
		negocio.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		negocio.setBounds(10, 211, 119, 23);
		negocio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Contratos frame = new Contratos();
				frame.setVisible(true);
			}
			});
		contentPane.add(negocio);
		negocio.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		
		JButton boton4 = new JButton("Patrocinadores");
		boton4.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		boton4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Patrocinadores frame = new Patrocinadores();
				frame.setVisible(true);
			}
			});
		
		boton4.setBounds(10, 253, 119, 23);
		contentPane.add(boton4);
		boton4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		
		JLabel lblNewLabel_1 = new JLabel("Telefonos De Departamentos:");
		lblNewLabel_1.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 17));
		lblNewLabel_1.setBounds(139, 11, 183, 30);
		contentPane.add(lblNewLabel_1);
		
		JList list = new JList();
		list.setToolTipText("");
		extracted(list);
		list.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 17));
		list.setBounds(332, 11, 318, 91);
		contentPane.add(list);
		
		JTextPane textPane = new JTextPane();
		textPane.setBounds(160, 151, 490, 91);
		contentPane.add(textPane);
		
		JButton GardarArchivo = new JButton("Guardar Documento");
		GardarArchivo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		GardarArchivo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(seleccionar.showDialog(null,"Guardar Archivo")==JFileChooser.APPROVE_OPTION) {
					Archivo=seleccionar.getSelectedFile();
						if(Archivo.getName().endsWith("txt")) {
							String Documento=textPane.getText();
							String Mensaje=GuardarArchivo(Archivo,Documento);
								if(Mensaje!=null) {
									JOptionPane.showMessageDialog(null, Mensaje);
									}else {
									JOptionPane.showMessageDialog(null,"Archivo No Compatible");
									}
						}else {
							JOptionPane.showMessageDialog(null, "Guardar Documento De Texto");
						}
			}
			}
		});
		GardarArchivo.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		GardarArchivo.setBounds(498, 267, 152, 23);
		contentPane.add(GardarArchivo);
		
		JButton AbrirArchivo = new JButton("Abrir Documento");
		AbrirArchivo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		AbrirArchivo.addActionListener(new ActionListener() {
			

			public void actionPerformed(ActionEvent e) {
				
				if(seleccionar.showDialog(null,"Abrir Archivo")==JFileChooser.APPROVE_OPTION) {
					Archivo=seleccionar.getSelectedFile();
					if(Archivo.canRead()) {
						if(Archivo.getName().endsWith("txt")) {
							String Documento=AbrirArchivo(Archivo);
							textPane.setText(Documento);
							
						}else {
							JOptionPane.showMessageDialog(null,"Archivo no Compatible");
						}
					}
				}
			}
		});
		AbrirArchivo.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		AbrirArchivo.setBounds(160, 267, 139, 23);
		contentPane.add(AbrirArchivo);
		
		JLabel lblNewLabel_2 = new JLabel("Pendientes:");
		lblNewLabel_2.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_2.setBounds(155, 126, 167, 14);
		contentPane.add(lblNewLabel_2);
		
		JButton btnRegresar = new JButton("Regresar");
		btnRegresar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnRegresar.setBounds(10, 303, 119, 23);
		contentPane.add(btnRegresar);
		btnRegresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\jaime\\Desktop\\FabricaAutoPartesv8\\res\\icono-user.png"));
		lblNewLabel_3.setBounds(10, 20, 119, 82);
		contentPane.add(lblNewLabel_3);
		btnRegresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 regresar();
			}
			
			private void regresar() {
				setVisible(false);
				
			}
		});
	
		initComponents();
		
	}

	private void extracted(JList list) {
		list.setModel(new AbstractListModel() {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;
			String[] values = new String[] {"Finanzas : 55-66-89-10-21", "Ti : 55-23-12-43-54", "Recursos Humanos : 55-09-32-57-32", "Produccion: 55-23-17-43-23", "Comercial : 55-12-76-34-21"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
	}

	public String AbrirArchivo(File Archivo) {
		String Documento="";
		
		try{
			entrada=new FileInputStream(Archivo);
			int ascci;
			while((ascci=entrada.read())!=-1) {
				char caracter = (char) ascci;
				Documento+=caracter;
			}
			} catch (Exception e) {
				
		}
		return Documento;
	}
	public String GuardarArchivo(File Archivo, String Documento) {
		String mensaje=null;
		try {
			salida=new FileOutputStream(Archivo);
			byte[] bytxt=Documento.getBytes();
			salida.write(bytxt);
			mensaje="Archivo Guardado";
		}catch (Exception e) {
	}
	return mensaje;
	}
	
	private void initComponents() {
		// TODO Auto-generated method stub
		
	}
	
	
	}


		 

