package formulario;
import java.awt.BorderLayout;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Logistica.Logistica;
import Produccion.Almacen;
import direccion_finanzas.Finanzas;
import recursos_humanos.EmpleadoNuevo;
import recursos_humanos.rrhh;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;
import java.awt.Window;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Gui extends JFrame implements ActionListener{






	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Window f = null;
	private JPanel contentPane;
	private ImageIcon image;
	private JLabel ImageLabel;
	private JPanel ImagePanel;
	private JComboBox comboBoxdpto;
	private JButton btnNewButton;
	private JButton btnAceptar;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gui frame = new Gui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	
	public Gui() {
		
		//Crea el Panel para toda la Ventana de la APP
		setTitle("AutoPartesSoftware");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 894, 784);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//Crea el combo Box
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Dialog", Font.PLAIN, 20));
		comboBoxdpto= new JComboBox (new String[] {"","Finanzas","Direccion General", "Logistica","Almacen", "Recursos Humanos"});
		comboBoxdpto.setSelectedIndex(0);
		final int comboboxObject = comboBoxdpto.getSelectedIndex();
		comboBoxdpto.setForeground(new Color(0, 51, 153));
		comboBoxdpto.setFont(new Font("Dialog", Font.PLAIN, 40));
		comboBoxdpto.setBounds(210, 427, 464, 162);
		contentPane.add(comboBoxdpto);
		
		
		//El texto  de Selecciona tu departamento
		JLabel Labeldpto = new JLabel("Selecciona tu departamento:");
		Labeldpto.setForeground(new Color(102, 153, 204));
		Labeldpto.setFont(new Font("Dialog", Font.BOLD, 23));
		Labeldpto.setBounds(275, 377, 326, 60);
		contentPane.add(Labeldpto);
	
		//
		ImagePanel = new JPanel();
		ImagePanel.setBounds(189, 11, 510, 355);
		ImagePanel.setBackground(Color.white);
		ImageLabel = new JLabel();
		image = new ImageIcon(getClass().getClassLoader().getResource("AutoPartes.jpg"));
		ImageLabel.setIcon(image);
		ImagePanel.add(ImageLabel);
		contentPane.add(ImagePanel);	
		
		btnAceptar = new JButton();
		  try {
		    Image img = ImageIO.read(getClass().getClassLoader().getResource("acierto.png"));
		    btnAceptar.setIcon(new ImageIcon(img));
		  } catch (Exception ex) {
		    System.out.println(ex);
		  }
		btnAceptar.addActionListener(this);
		btnAceptar.setBounds(372, 652, 125, 51);
		btnAceptar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		contentPane.add(btnAceptar);
	}
	
	public void actionPerformed(ActionEvent e) {
	      int selectedIndex = comboBoxdpto.getSelectedIndex();
	      
	      
	        switch (selectedIndex) {
	        /*case 0: //COMERCIAL
	        	System.out.println("Comercial Aceptar");
	        	p.setVisible(true);
	        	break;*/
	        	
	        case 1: //FINANZAS
	        	System.out.println("Finanzas Seleccionado");
	        	
	        	Finanzas frame5 = new Finanzas();
				frame5.setVisible(true);
			
				
	        	break;
	        	
	        case 2: //DIRECCION GENERAL
	        	System.out.println("Direccion General Seleccionado");
	        	Dgeneral frame = new Dgeneral();
				frame.setVisible(true);
	        	break;
	        	
	        case 3: //LOGISTICA
	        	System.out.println("Logistica Seleccionado");
	        	Logistica frame1 = new Logistica();
				frame1.setVisible(true);
	        	break;
	        	
	        case 4: //PRODUCCION
	        	System.out.println("Almacen");
	        	Almacen framew = new Almacen();
				framew.setVisible(true);
	        	break;
	        	
	        case 5: //RECURSOS HUMANOS
	        	System.out.println("Recursos Humanos");
	        	rrhh frame3 = new rrhh();
				frame3.setVisible(true);
		       	break;
		       	
	       /* case 6: //TI
	        	System.out.println("TI");
	        	p.setVisible(true);
		       	break; */
	        }
	}
}