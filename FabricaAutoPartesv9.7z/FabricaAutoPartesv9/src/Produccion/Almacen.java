package Produccion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;

import utils.MySQLConexion;

public class Almacen extends JFrame {

	private void eliminar() {
		 txtidproducto.setText(null);
	      txtnumeroprod.setText(null);
	      txtdescripcion.setText(null);
	      txtexistencia.setText(null);
	      txtcosto.setText(null);
	}
	private void limpiarcajas() {
		
		 txtidproducto.setText(null);
	      txtnumeroprod.setText(null);
	      txtdescripcion.setText(null);
	      txtexistencia.setText(null);
	      txtcosto.setText(null);
	}
	
	public static Connection getconexion() {
		Connection con =null;
		

	    
	    try {
	        Class.forName("com.mysql.jdbc.Driver");
	      String url = "jdbc:mysql://localhost:3306/cartas_1";
	      String usr ="root";
	      String psw = "James1509";
	      
	      PreparedStatement ps;
	      ResultSet rs;
	      
	      con = DriverManager.getConnection(url,usr,psw);
	   

	    } catch (ClassNotFoundException e) {
	        System.out.println("Error al cargar el controlador");
	      

	    } catch (SQLException e) {
	        System.out.println("Error en la conexi�n a base de datos");
	    }
	    
	    return con;
	}


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtidproducto;
	private JTextField txtnumeroprod;
	private JTextField txtdescripcion;
	private JTextField txtexistencia;
	private JTextField txtcosto;
	private JButton  limpiar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Almacen frame = new Almacen();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Almacen() {
		setTitle("Almacen");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 597, 300);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setIcon(new ImageIcon("C:\\Users\\jaime\\Desktop\\FabricaAutoPartesv8\\res\\Logov.jpg"));
		lblNewLabel_5.setBounds(432, 41, 147, 149);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel = new JLabel("Numero de Serie");
		lblNewLabel.setBounds(10, 31, 104, 14);
		contentPane.add(lblNewLabel);
		
		txtidproducto = new JTextField();
		txtidproducto.setBounds(165, 28, 257, 20);
		contentPane.add(txtidproducto);
		txtidproducto.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Nombre de la pieza");
		lblNewLabel_1.setBounds(10, 76, 141, 14);
		contentPane.add(lblNewLabel_1);
		
		txtnumeroprod = new JTextField();
		txtnumeroprod.setBounds(161, 73, 261, 20);
		contentPane.add(txtnumeroprod);
		txtnumeroprod.setColumns(10);
		
		JButton btnNewButton = new JButton("Buscar");
		btnNewButton.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnNewButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnNewButton.setBounds(119, 227, 89, 23);
		btnNewButton.addActionListener(new ActionListener() {
			private PreparedStatement ps;
			private ResultSet rs;

			public void actionPerformed(ActionEvent e) {
				Connection con = null;
				
				try {
                    con = MySQLConexion.getconexion();
					
					
					ps= con.prepareStatement("SELECT * FROM produccion WHERE idproducto =?");
					ps.setString(1,txtidproducto.getText());
			      
			      
					
					rs = ps.executeQuery();
					
					if(rs.next()) {
						 txtidproducto.setText(rs.getString("idproducto"));
					      txtnumeroprod.setText(rs.getString("numeroprod")); 
					      txtdescripcion.setText(rs.getString("descripcion"));
					      txtexistencia.setText(rs.getString("existencia"));
					      txtcosto.setText(rs.getString("costo"));
					      
					     
					      
					}else {
						JOptionPane.showMessageDialog(null,"producto no existente");
						
					}
			    	
				}catch(Exception e1) {

					System.err.println(e1);
				
				}
			}
		});
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Agregar");
		btnNewButton_1.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnNewButton_1.setBounds(10, 227, 89, 23);
		contentPane.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			private Connection con;
			private PreparedStatement ps;
			
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				Connection con = null;
			
				try {
					
					con = MySQLConexion.getconexion();
					
					
					ps= con.prepareStatement("INSERT INTO produccion(idproducto, numeroprod, descripcion, existencia, costo) VALUES(?, ?, ?, ?, ?)");
			        ps.setString(1,txtidproducto.getText());
			        ps.setString(2,txtnumeroprod.getText());
			        ps.setString(3,txtdescripcion.getText());
			        ps.setString(4,txtexistencia.getText());
			        ps.setString(5,txtcosto.getText());
			     
			      
			       
			    	
			     
					int rs = ps.executeUpdate();

					if (rs > 0) {
						JOptionPane.showMessageDialog(null,"producto nuevo agregado ");
						eliminar();
					}else {
						JOptionPane.showMessageDialog(null,"error al introducir produto nuevo");
						eliminar();
					}
					
					con.close();
					
				
				}catch(Exception e) {

					System.err.println(e);
				
				}
			}		
				
		});
	
		
		
		
		JLabel lblNewLabel_2 = new JLabel("Descripcion");
		lblNewLabel_2.setBounds(10, 114, 104, 14);
		contentPane.add(lblNewLabel_2);
		
		txtdescripcion = new JTextField();
		txtdescripcion.setBounds(161, 111, 261, 20);
		contentPane.add(txtdescripcion);
		txtdescripcion.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Existencia");
		lblNewLabel_3.setBounds(10, 151, 104, 14);
		contentPane.add(lblNewLabel_3);
		
		txtexistencia = new JTextField();
		txtexistencia.setBounds(161, 148, 261, 20);
		contentPane.add(txtexistencia);
		txtexistencia.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Costo de Elaboracion");
		lblNewLabel_4.setBounds(10, 189, 141, 14);
		contentPane.add(lblNewLabel_4);
		
		txtcosto = new JTextField();
		txtcosto.setText("$");
		txtcosto.setBounds(161, 186, 261, 20);
		contentPane.add(txtcosto);
		txtcosto.setColumns(10);
		
		JButton btnRegresar = new JButton("Regresar");
		btnRegresar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnRegresar.setBounds(465, 227, 89, 23);
		contentPane.add(btnRegresar);
		btnRegresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnRegresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 regresar();
			}
			
			private void regresar() {
				setVisible(false);
				
			}
		});
		JButton limpiar = new JButton("Limpiar");
		limpiar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		limpiar.setBounds(333, 227, 89, 23);
		contentPane.add(limpiar);
		limpiar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		limpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
			
				  limpiarcajas();
			}
			
				
					    	
		});
				
		contentPane.add(btnNewButton);
		
		JButton Eliminar = new JButton("Eliminar");
		Eliminar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		Eliminar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		Eliminar.addActionListener(new ActionListener() {
			private PreparedStatement ps;

			public void actionPerformed(ActionEvent arg0) {
				Connection con = null;
				
				try {
					
					con = MySQLConexion.getconexion();
					
					
					ps= con.prepareStatement("DELETE FROM produccion WHERE idproducto=?");
			        ps.setInt(1, Integer.parseInt(txtidproducto.getText()));
			        
			    	
					int rs = ps.executeUpdate();

					if (rs > 0) {
						JOptionPane.showMessageDialog(null,"producto eliminado ");
						eliminar();
					}else {
						JOptionPane.showMessageDialog(null,"error al eliminar producto ");
						eliminar();
					}
					
					con.close();
					
				
				}catch(Exception e) {

					System.err.println(e);
				
				}
			}		
			
		});
		Eliminar.setBounds(228, 227, 89, 23);
		contentPane.add(Eliminar);
		
			       
		
		
		
	}
}


