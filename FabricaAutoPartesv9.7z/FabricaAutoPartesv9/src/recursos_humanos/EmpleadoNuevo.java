package recursos_humanos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;

import utils.MySQLConexion;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;


public class EmpleadoNuevo extends JFrame {
	
	
	private void eliminar() {
		 txtnomina.setText(null);
	      txtappat.setText(null);
	      txtapmat.setText(null);
	      ttxtnombre.setText(null);
	      txtdpto.setText(null);
		
	}


private void limpiarcajas() {
	 txtnomina.setText(null);
      txtappat.setText(null);
      txtapmat.setText(null);
      ttxtnombre.setText(null);
      txtdpto.setText(null);
	
}
	public static Connection getconexion() {
	Connection con =null;

    
    try {
        Class.forName("com.mysql.jdbc.Driver");
      String url = "jdbc:mysql://localhost:3306/cartas_1";
      String usr ="root";
      String psw = "ROOT";
      
      PreparedStatement ps;
      ResultSet rs;
      
      con = DriverManager.getConnection(url,usr,psw);
   

    } catch (ClassNotFoundException e) {
        System.out.println("Error al cargar el controlador");
      

    } catch (SQLException e) {
        System.out.println("Error en la conexi�n a base de datos");
    }
    
    return con;
}

	private JPanel contentPane;
	private JTextField txtnomina;
	private JTextField txtappat;
	private JTextField txtapmat;
	private JTextField ttxtnombre;
	private JTextField txtdpto;
	private JButton btnSalir;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EmpleadoNuevo frame = new EmpleadoNuevo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EmpleadoNuevo() {
		setTitle("Empleados");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 650, 376);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel Lnomina = new JLabel("No.Nomina");
		Lnomina.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		Lnomina.setBounds(10, 50, 116, 14);
		contentPane.add(Lnomina);
		
		txtnomina = new JTextField();
		txtnomina.setBounds(115, 48, 302, 20);
		contentPane.add(txtnomina);
		txtnomina.setColumns(10);
		
		
		JLabel Lappat = new JLabel("Apellido Paterno");
		Lappat.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		Lappat.setBounds(10, 98, 116, 14);
		contentPane.add(Lappat);
		
		txtappat = new JTextField();
		txtappat.setBounds(115, 96, 302, 20);
		contentPane.add(txtappat);
		txtappat.setColumns(10);
		
		JLabel Lapmat = new JLabel("Appellido Materno");
		Lapmat.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		Lapmat.setBounds(10, 144, 116, 14);
		contentPane.add(Lapmat);
		
		txtapmat = new JTextField();
		txtapmat.setBounds(115, 142, 302, 20);
		contentPane.add(txtapmat);
		txtapmat.setColumns(10);
		
		JLabel Lnombre = new JLabel("Nombre");
		Lnombre.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		Lnombre.setBounds(10, 196, 116, 14);
		contentPane.add(Lnombre);
		
		ttxtnombre = new JTextField();
		ttxtnombre.setBounds(115, 194, 302, 20);
		contentPane.add(ttxtnombre);
		ttxtnombre.setColumns(10);
		
		JLabel Ldpto = new JLabel("Departamento");
		Ldpto.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		Ldpto.setBounds(10, 244, 116, 14);
		contentPane.add(Ldpto);
		
		txtdpto = new JTextField();
		txtdpto.setBounds(115, 242, 302, 20);
		contentPane.add(txtdpto);
		txtdpto.setColumns(10);
		
		JButton btnAgregar = new JButton("Agregar");
		btnAgregar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnAgregar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnAgregar.setBounds(10, 291, 119, 23);
		contentPane.add(btnAgregar);
		btnAgregar.addActionListener(new ActionListener() {
			private Connection con;
			private PreparedStatement ps;
			
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				Connection con = null;
			
				try {
					
					con = MySQLConexion.getconexion();
					
					
					ps= con.prepareStatement("INSERT INTO ingreso( nomina, apellidop, apellidom, nombre, departamento ) VALUES(?, ?, ?, ?, ?)");
			        ps.setString(1,txtnomina.getText());
			        ps.setString(2,txtappat.getText());
			        ps.setString(3,txtapmat.getText());
			        ps.setString(4,ttxtnombre.getText());
			        ps.setString(5,txtdpto.getText());
			       
			    	
			     
					int rs = ps.executeUpdate();

					if (rs > 0) {
						JOptionPane.showMessageDialog(null,"empleado nuevo agregado ");
						eliminar();
					}else {
						JOptionPane.showMessageDialog(null,"error al introducir empleado nuevo");
						eliminar();
					}
					
					con.close();
					
				
				}catch(Exception e) {

					System.err.println(e);
				
				}
			}		
				
		});
		btnAgregar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		
		JButton btnRegresar = new JButton("Regresar");
		btnRegresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnRegresar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnRegresar.setBounds(475, 210, 119, 23);
		contentPane.add(btnRegresar);
		
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnBuscar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		 btnBuscar.addActionListener(new ActionListener() {
			private PreparedStatement ps;
			private ResultSet rs;

			public void actionPerformed(ActionEvent e) {
				Connection con = null;
				
				try {
                    con = MySQLConexion.getconexion();
					
					
					ps= con.prepareStatement("SELECT * FROM ingreso WHERE nomina =?");
					ps.setString(1,txtnomina.getText());
			      
			      
					
					rs = ps.executeQuery();
					
					if(rs.next()) {
						 txtnomina.setText(rs.getString("nomina"));
					      txtappat.setText(rs.getString("apellidop")); 
					      txtapmat.setText(rs.getString("apellidom"));
					      ttxtnombre.setText(rs.getString("nombre"));
					      txtdpto.setText(rs.getString("departamento"));
					      
					     
					      
					}else {
						JOptionPane.showMessageDialog(null,"empleado no existente");
						
					}
			    	
				}catch(Exception e1) {

					System.err.println(e1);
				
				}
			}
		});
		btnBuscar.setBounds(139, 291, 119, 23);
		contentPane.add(btnBuscar);
		
		JButton btnAgregar_1_1 = new JButton("Eliminar");
		btnAgregar_1_1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnAgregar_1_1.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnAgregar_1_1.addActionListener(new ActionListener() {
			private PreparedStatement ps;

			public void actionPerformed(ActionEvent arg0) {
				Connection con = null;
				
				try {
					
					con = MySQLConexion.getconexion();
					
					
					ps= con.prepareStatement("DELETE FROM ingreso WHERE nomina=?");
			        ps.setInt(1, Integer.parseInt(txtnomina.getText()));
			        
			    	
					int rs = ps.executeUpdate();

					if (rs > 0) {
						JOptionPane.showMessageDialog(null,"empleado eliminado ");
						eliminar();
					}else {
						JOptionPane.showMessageDialog(null,"error al eliminar empleado ");
						eliminar();
					}
					
					con.close();
					
				
				}catch(Exception e) {

					System.err.println(e);
				
				}
			}		
			
		});
		btnAgregar_1_1.setBounds(402, 291, 119, 23);
		contentPane.add(btnAgregar_1_1);
		
		JButton btnLimpiar = new JButton("Limpiar");
		btnLimpiar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnLimpiar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnLimpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
			
				  limpiarcajas();
			}
			
				
					    	
		});
		btnLimpiar.setBounds(273, 291, 119, 23);
		contentPane.add(btnLimpiar);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\jaime\\Desktop\\FabricaAutoPartesv8\\res\\Logov.jpg"));
		lblNewLabel.setBounds(462, 47, 146, 211);
		contentPane.add(lblNewLabel);
		btnRegresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 regresar();
			}
			
			private void regresar() {
				setVisible(false);
				
			}
		});
	}
}
