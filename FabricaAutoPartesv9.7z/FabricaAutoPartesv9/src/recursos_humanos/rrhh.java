package recursos_humanos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollBar;
import javax.swing.border.BevelBorder;
import javax.swing.ListSelectionModel;

public class rrhh extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					rrhh frame = new rrhh();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public rrhh() {
		setTitle("Recursos Humanos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 676, 376);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		setContentPane(contentPane);
		contentPane.setLayout(null);
			
		
		JButton btnempleadonew = new JButton("Empleado Nuevo");
		btnempleadonew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 btnempleadonewactionPerformed(arg0);
			}
		});
		btnempleadonew.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnempleadonew.setBounds(10, 109, 119, 23);
		contentPane.add(btnempleadonew);
		btnempleadonew.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
	
		
		JLabel Label1 = new JLabel("Personal:");
		Label1.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		Label1.setBounds(183, 11, 167, 14);
		contentPane.add(Label1);

		
		table = new JTable();
		table.setSurrendersFocusOnKeystroke(true);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setToolTipText("");
		table.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{new Integer(1), "Leon y Velez", "Mendez", "Juan", "TI"},
				{new Integer(2), null, null, null, null},
				{new Integer(3), null, null, null, null},
				{new Integer(4), null, null, null, null},
				{new Integer(5), null, null, null, null},
				{new Integer(6), null, null, null, null},
				{new Integer(7), null, null, null, null},
			},
			new String[] {
				"No. Nomina", "Paterno", "Materno", "Nombre", "Departamento"
			}
		) {
			Class[] columnTypes = new Class[] {
				Object.class, String.class, Object.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		table.getColumnModel().getColumn(0).setPreferredWidth(95);
		table.getColumnModel().getColumn(1).setPreferredWidth(91);
		table.getColumnModel().getColumn(2).setPreferredWidth(93);
		table.getColumnModel().getColumn(3).setPreferredWidth(83);
		table.getColumnModel().getColumn(4).setPreferredWidth(93);
		table.setBounds(183, 36, 403, 212);
		table.setPreferredScrollableViewportSize(new Dimension(450,63));
        table.setFillsViewportHeight(true);
		contentPane.add(table);
		
		
		JScrollBar scrollBar = new JScrollBar();
		scrollBar.setForeground(Color.WHITE);
		scrollBar.setBounds(585, 36, 17, 212);
		contentPane.add(scrollBar);
		
		JButton btnSalir = new JButton("Salir");
		btnSalir.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnSalir.setBounds(483, 291, 119, 23);
		contentPane.add(btnSalir);
		btnSalir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 salir();
			}
			
			private void salir() {
				System.exit(0);
				
			}
		});
		
		JButton btnRegresar = new JButton("Regresar");
		btnRegresar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnRegresar.setBounds(10, 291, 119, 23);
		contentPane.add(btnRegresar);
		btnRegresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnRegresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 regresar();
			}
			
			private void regresar() {
				setVisible(false);
				
			}
		});
		
		
	}
	
	public void btnempleadonewactionPerformed(ActionEvent e) {
		EmpleadoNuevo empnew = new EmpleadoNuevo();
		empnew.setVisible(true);
	}

}
	
