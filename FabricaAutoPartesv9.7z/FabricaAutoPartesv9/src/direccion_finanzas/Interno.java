package direccion_finanzas;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import utils.MySQLConexion;

import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JTextPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;

import java.awt.Font;

public class Interno extends JFrame {
	private void limpiarcajas() {
		
		 txtidproducto.setText(null);
	      txtnumeroprod.setText(null);
	      txtdescripcion.setText(null);
	      txtexistencia.setText(null);
	      txtcosto.setText(null);
	}
	

	private JPanel contentPane;
	JFileChooser seleccionar = new JFileChooser ();
    File Archivo;
    FileInputStream entrada;
    FileOutputStream salida;
    private JTextField txtidproducto;
    private JTextField txtnumeroprod;
    private JTextField txtdescripcion;
    private JTextField txtexistencia;
    private JTextField txtcosto;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Interno frame = new Interno();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Interno() {
		setTitle("Interno");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 708, 378);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextPane txtpnNotas = new JTextPane();
		txtpnNotas.setText("NOTAS PARA PRODUCC\u00D2N:");
		txtpnNotas.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtpnNotas.setBounds(10, 11, 389, 197);
		contentPane.add(txtpnNotas);
		
		JButton AbrirDocumento = new JButton("Abrir");
		AbrirDocumento.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		AbrirDocumento.setBounds(10, 234, 124, 23);
		contentPane.add(AbrirDocumento);
		AbrirDocumento.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		AbrirDocumento.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
						
						if(seleccionar.showDialog(null,"Abrir Archivo")==JFileChooser.APPROVE_OPTION) {
							Archivo=seleccionar.getSelectedFile();
							if(Archivo.canRead()) {
								if(Archivo.getName().endsWith("txt")) {
									String Documento=Abrir(Archivo);
									txtpnNotas.setText(Documento);
									
								}else {
									JOptionPane.showMessageDialog(null,"Archivo no Compatible");
								}
							}
						}
					}

				public String Abrir(File archivo) {
					String Documento="";
					
					try{
						entrada=new FileInputStream(Archivo);
						int ascci;
						while((ascci=entrada.read())!=-1) {
							char caracter = (char) ascci;
							Documento+=caracter;
						}
						} catch (Exception e) {
							
					}
					return Documento;
				}
				
			});
	
	
		
		JButton GuardarDocumento = new JButton("Guardar");
		GuardarDocumento.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		GuardarDocumento.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		GuardarDocumento.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			if(seleccionar.showDialog(null,"Guardar Archivo")==JFileChooser.APPROVE_OPTION) {
				Archivo=seleccionar.getSelectedFile();
					if(Archivo.getName().endsWith("txt")) {
						String Documento=txtpnNotas.getText();
						String Mensaje=GuardarDocumento(Archivo,Documento);
							if(Mensaje!=null) {
								JOptionPane.showMessageDialog(null, Mensaje);
								}else {
								JOptionPane.showMessageDialog(null,"Archivo No Compatible");
								}
					}else {
						JOptionPane.showMessageDialog(null, "Guardar Documento De Texto");
					}
		}
		}

		private String GuardarDocumento(File archivo, String documento) {
			String mensaje=null;
			try {
				salida=new FileOutputStream(Archivo);
				byte[] bytxt=documento.getBytes();
				salida.write(bytxt);
				mensaje="Archivo Guardado";
			}catch (Exception e) {
		}
		return mensaje;
		}
		
	});
		GuardarDocumento.setBounds(275, 234, 124, 23);
		contentPane.add(GuardarDocumento);
		
		JButton regresar = new JButton("Regresar");
		regresar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
	  regresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		regresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 regresar();
			}
			
			private void regresar() {
				setVisible(false);
				
			}
		});
		
		regresar.setBounds(558, 302, 124, 23);
		contentPane.add(regresar);
		
		JButton btnSupervisin = new JButton("Buscar");
		btnSupervisin.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnSupervisin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnSupervisin.addActionListener(new ActionListener() {
		
				private PreparedStatement ps;
				private ResultSet rs;

				public void actionPerformed(ActionEvent e) {
					Connection con = null;
					
					try {
	                    con = MySQLConexion.getconexion();
						
						
						ps= con.prepareStatement("SELECT * FROM produccion WHERE idproducto =?");
						ps.setString(1,txtidproducto.getText());
				      
				      
						
						rs = ps.executeQuery();
						
						if(rs.next()) {
							 txtidproducto.setText(rs.getString("idproducto"));
						      txtnumeroprod.setText(rs.getString("numeroprod")); 
						      txtdescripcion.setText(rs.getString("descripcion"));
						      txtexistencia.setText(rs.getString("existencia"));
						      txtcosto.setText(rs.getString("costo"));
						      
						     
						      
						}else {
							JOptionPane.showMessageDialog(null,"producto no existente");
							
						}
				    	
					}catch(Exception e1) {

						System.err.println(e1);
					
					}
				}
			
			
			});
		btnSupervisin.setBounds(558, 234, 124, 23);
		contentPane.add(btnSupervisin);
		
		txtidproducto = new JTextField();
		txtidproducto.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtidproducto.setBounds(482, 11, 200, 20);
		contentPane.add(txtidproducto);
		txtidproducto.setColumns(10);
		
		txtnumeroprod = new JTextField();
		txtnumeroprod.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtnumeroprod.setColumns(10);
		txtnumeroprod.setBounds(482, 55, 200, 23);
		contentPane.add(txtnumeroprod);
		
		txtdescripcion = new JTextField();
		txtdescripcion.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtdescripcion.setColumns(10);
		txtdescripcion.setBounds(482, 102, 200, 23);
		contentPane.add(txtdescripcion);
		
		txtexistencia = new JTextField();
		txtexistencia.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtexistencia.setColumns(10);
		txtexistencia.setBounds(482, 145, 200, 20);
		contentPane.add(txtexistencia);
		
		txtcosto = new JTextField();
		txtcosto.setText("$");
		txtcosto.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtcosto.setColumns(10);
		txtcosto.setBounds(482, 188, 200, 20);
		contentPane.add(txtcosto);
		
		JLabel lblNewLabel = new JLabel("Serie");
		lblNewLabel.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel.setBounds(405, 11, 94, 20);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Nombre");
		lblNewLabel_1.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1.setBounds(409, 55, 94, 20);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Descripci\u00F2n");
		lblNewLabel_1_1.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1_1.setBounds(409, 101, 94, 20);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Existencia");
		lblNewLabel_1_2.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1_2.setBounds(405, 145, 106, 20);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Costo ");
		lblNewLabel_1_3.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1_3.setBounds(405, 188, 106, 20);
		contentPane.add(lblNewLabel_1_3);
		
		JButton btnLimpiar = new JButton("Limpiar");
		btnLimpiar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnLimpiar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnLimpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
			
				  limpiarcajas();
			}
			
				
					    	
		});
		btnLimpiar.setBounds(558, 268, 124, 23);
		contentPane.add(btnLimpiar);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\jaime\\Desktop\\FabricaAutoPartesv8\\res\\Logov.jpg"));
		lblNewLabel_2.setBounds(138, 234, 132, 94);
		contentPane.add(lblNewLabel_2);
	}
}
