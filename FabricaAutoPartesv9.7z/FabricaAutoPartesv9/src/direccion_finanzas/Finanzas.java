package direccion_finanzas;

import java.awt.BorderLayout;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.border.MatteBorder;
import java.awt.Color;
import javax.swing.table.DefaultTableModel;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFormattedTextField;
import javax.swing.JSeparator;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JSlider;
import javax.swing.JList;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JTextPane;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.DefaultComboBoxModel;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.awt.event.ActionEvent;

public class Finanzas extends JFrame {

	private static final Object Presupuesto = null;
	protected static final String documento = null;
	JFileChooser seleccionar = new JFileChooser ();
    File Archivo;
    FileInputStream entrada;
    FileOutputStream salida;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Finanzas frame = new Finanzas();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Finanzas() {
		setTitle("Finanzas");
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\jaime\\Desktop\\FabricaAutoPartes\\res\\AutoPartes.jpg"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 537, 327);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Riesgos");
		btnNewButton.setIcon(new ImageIcon(Finanzas.class.getResource("/javax/swing/plaf/metal/icons/Warn.gif")));
		btnNewButton.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 18));
		btnNewButton.setBounds(315, 252, 175, 34);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Riesgos frame = new Riesgos();
				frame.setVisible(true);
			}
			});
		
		btnNewButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		contentPane.add(btnNewButton);
		
		JTextPane txtpnBuscarNotasDe = new JTextPane();
		txtpnBuscarNotasDe.setText("Buscar Notas de Departamentos:");
		txtpnBuscarNotasDe.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtpnBuscarNotasDe.setBounds(10, 11, 266, 171);
		contentPane.add(txtpnBuscarNotasDe);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 17));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Funciones :", "Control Interno"}));
		comboBox.setBounds(286, 11, 230, 20);
		contentPane.add(comboBox);
		
		JButton GuardarDocumento = new JButton("Guardar");
		GuardarDocumento.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		GuardarDocumento.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(seleccionar.showDialog(null,"Guardar Archivo")==JFileChooser.APPROVE_OPTION) {
					Archivo=seleccionar.getSelectedFile();
						if(Archivo.getName().endsWith("txt")) {
							String Documento=txtpnBuscarNotasDe.getText();
							String Mensaje=GuardarDocumento(Archivo,Documento);
								if(Mensaje!=null) {
									JOptionPane.showMessageDialog(null, Mensaje);
									}else {
									JOptionPane.showMessageDialog(null,"Archivo No Compatible");
									}
						}else {
							JOptionPane.showMessageDialog(null, "Guardar Documento De Texto");
						}
			}
			}

			private String GuardarDocumento(File archivo, String documento) {
				String mensaje=null;
				try {
					salida=new FileOutputStream(Archivo);
					byte[] bytxt=documento.getBytes();
					salida.write(bytxt);
					mensaje="Archivo Guardado";
				}catch (Exception e) {
			}
			return mensaje;
			}
			
		});
		GuardarDocumento.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		GuardarDocumento.setBounds(164, 193, 112, 23);
		contentPane.add(GuardarDocumento);
		
		JButton Abrir = new JButton("Abrir");
		 Abrir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		Abrir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					
					if(seleccionar.showDialog(null,"Abrir Archivo")==JFileChooser.APPROVE_OPTION) {
						Archivo=seleccionar.getSelectedFile();
						if(Archivo.canRead()) {
							if(Archivo.getName().endsWith("txt")) {
								String Documento=Abrir(Archivo);
								txtpnBuscarNotasDe.setText(Documento);
								
							}else {
								JOptionPane.showMessageDialog(null,"Archivo no Compatible");
							}
						}
					}
				}

			public String Abrir(File archivo) {
				String Documento="";
				
				try{
					entrada=new FileInputStream(Archivo);
					int ascci;
					while((ascci=entrada.read())!=-1) {
						char caracter = (char) ascci;
						Documento+=caracter;
					}
					} catch (Exception e) {
						
				}
				return Documento;
			}
			
		});
		Abrir.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		Abrir.setBounds(10, 193, 112, 23);
		contentPane.add(Abrir);
		
		JButton btnNewButton_1 = new JButton("Aceptar");
		 btnNewButton_1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 int selectedIndex = comboBox.getSelectedIndex();
			        switch (selectedIndex) {
			        case 0: //Funciones
			        	System.out.println("Funciones");
			             Finanzas();
			        	break;
			        	
			        case 1: //Control Interno
			        	System.out.println("Control Interno");
			        	Interno frame = new Interno();
						frame.setVisible(true);
			        	break;
			        	
			      
			}
			}
			
			
			

			private void Finanzas() {
				// TODO Auto-generated method stub
				
			}
		});
		btnNewButton_1.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_1.setBounds(315, 198, 175, 33);
		contentPane.add(btnNewButton_1);
		
		JButton btnRegresar = new JButton("Regresar");
		btnRegresar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnRegresar.setBounds(89, 258, 119, 23);
		contentPane.add(btnRegresar);
		btnRegresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\jaime\\Desktop\\FabricaAutoPartesv8\\res\\icono-user.png"));
		lblNewLabel.setBounds(344, 64, 146, 123);
		contentPane.add(lblNewLabel);
		btnRegresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 regresar();
			}
			
			private void regresar() {
				setVisible(false);
				
			}
		});
		
	}
}
