package direccion_finanzas;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import utils.MySQLConexion;

import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;

public class Riesgos extends JFrame {
	private void eliminar() {
		 txtidfolio.setText(null);
	      txta�o.setText(null);
	      txtmes.setText(null);
	      txtriesgo.setText(null);
	      txtarea.setText(null);
	      txtdescripcion.setText(null);
	}
	private void limpiarcajas() {
		
		 txtidfolio.setText(null);
	      txta�o.setText(null);
	      txtmes.setText(null);
	      txtriesgo.setText(null);
	      txtarea.setText(null);
	      txtdescripcion.setText(null);
	}
	
	public static Connection getconexion() {
		Connection con =null;
		

	    
	    try {
	        Class.forName("com.mysql.jdbc.Driver");
	      String url = "jdbc:mysql://localhost:3306/cartas_1";
	      String usr ="root";
	      String psw = "James1509";
	      
	      PreparedStatement ps;
	      ResultSet rs;
	      
	      con = DriverManager.getConnection(url,usr,psw);
	   

	    } catch (ClassNotFoundException e) {
	        System.out.println("Error al cargar el controlador");
	      

	    } catch (SQLException e) {
	        System.out.println("Error en la conexi�n a base de datos");
	    }
	    
	    return con;
	}


	private JPanel contentPane;
	private JTextField txtidfolio;
	private JTextField txta�o;
	private JTextField txtmes;
	private JTextField txtriesgo;
	private JTextField txtarea;
	private JTextField txtdescripcion;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Riesgos frame = new Riesgos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Riesgos() {
		setTitle("Riesgos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 561, 272);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtidfolio = new JTextField();
		txtidfolio.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtidfolio.setBounds(131, 13, 112, 33);
		contentPane.add(txtidfolio);
		txtidfolio.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Folio");
		lblNewLabel.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel.setBounds(10, 14, 97, 30);
		contentPane.add(lblNewLabel);
		
		txta�o = new JTextField();
		txta�o.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txta�o.setColumns(10);
		txta�o.setBounds(423, 11, 112, 33);
		contentPane.add(txta�o);
		
		txtmes = new JTextField();
		txtmes.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtmes.setColumns(10);
		txtmes.setBounds(131, 70, 112, 33);
		contentPane.add(txtmes);
		
		txtriesgo = new JTextField();
		txtriesgo.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtriesgo.setColumns(10);
		txtriesgo.setBounds(423, 78, 112, 33);
		contentPane.add(txtriesgo);
		
		txtarea = new JTextField();
		txtarea.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtarea.setColumns(10);
		txtarea.setBounds(131, 133, 112, 33);
		contentPane.add(txtarea);
		
		txtdescripcion = new JTextField();
		txtdescripcion.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtdescripcion.setColumns(10);
		txtdescripcion.setBounds(423, 133, 112, 33);
		contentPane.add(txtdescripcion);
		
		JLabel lblMes = new JLabel("Mes");
		lblMes.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblMes.setBounds(10, 71, 97, 30);
		contentPane.add(lblMes);
		
		JLabel lblArea = new JLabel("Area");
		lblArea.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblArea.setBounds(10, 126, 97, 30);
		contentPane.add(lblArea);
		
		JLabel lblAo = new JLabel("A\u00F1o");
		lblAo.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblAo.setBounds(292, 14, 97, 30);
		contentPane.add(lblAo);
		
		JLabel lblRiesgo = new JLabel("Riesgo");
		lblRiesgo.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblRiesgo.setBounds(292, 81, 97, 30);
		contentPane.add(lblRiesgo);
		
		JLabel lblDescripcin = new JLabel("Descripci\u00F2n");
		lblDescripcin.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblDescripcin.setBounds(292, 136, 97, 30);
		contentPane.add(lblDescripcin);
		
		JButton btnNewButton = new JButton("Agregar");
		btnNewButton.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnNewButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnNewButton.addActionListener(new ActionListener() {
			private Connection con;
			private PreparedStatement ps;
			
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				Connection con = null;
			
				try {
					
					con = MySQLConexion.getconexion();
					
					
					ps= con.prepareStatement("INSERT INTO presupuesto(idfolio, a�o, mes, riesgo, area, descripcion ) VALUES(?, ?, ?, ?, ?,?)");
			        ps.setString(1,txtidfolio.getText());
			        ps.setString(2,txta�o.getText());
			        ps.setString(3,txtmes.getText());
			        ps.setString(4,txtriesgo.getText());
			        ps.setString(5,txtarea.getText());
			        ps.setString(6,txtdescripcion.getText());
				       
			    	
			     
					int rs = ps.executeUpdate();

					if (rs > 0) {
						JOptionPane.showMessageDialog(null,"folio nuevo agregado ");
						eliminar();
					}else {
						JOptionPane.showMessageDialog(null,"error al introducir folio nuevo");
						eliminar();
					}
					
					con.close();
					
				
				}catch(Exception e) {

					System.err.println(e);
				
				}
			}		
				
		});
		btnNewButton.setBounds(10, 192, 89, 30);
		contentPane.add(btnNewButton);
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnBuscar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnBuscar.addActionListener(new ActionListener() {
			private PreparedStatement ps;
			private ResultSet rs;

			public void actionPerformed(ActionEvent e) {
				Connection con = null;
				
				try {
                   con = MySQLConexion.getconexion();
					
					
					ps= con.prepareStatement("SELECT * FROM presupuesto WHERE idfolio =?");
					ps.setString(1,txtidfolio.getText());
			      
			      
					
					rs = ps.executeQuery();
					
					if(rs.next()) {
						 txtidfolio.setText(rs.getString("idfolio"));
					      txta�o.setText(rs.getString("a�o")); 
					      txtmes.setText(rs.getString("mes"));
					      txtriesgo.setText(rs.getString("riesgo"));
					      txtarea.setText(rs.getString("area"));
					      txtdescripcion.setText(rs.getString("descripcion"));
					     
					      
					}else {
						JOptionPane.showMessageDialog(null,"folio no existente");
						
					}
			    	
				}catch(Exception e1) {

					System.err.println(e1);
				
				}
			}
		});
		btnBuscar.setBounds(131, 192, 112, 30);
		contentPane.add(btnBuscar);
		
		JButton btnLimpiar = new JButton("Limpiar");
		btnLimpiar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnLimpiar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnLimpiar.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				  limpiarcajas();
			}
			
				
			});
			
		btnLimpiar.setBounds(292, 192, 97, 30);
		contentPane.add(btnLimpiar);
		
		JButton btnRegresar = new JButton("Regresar");
		btnRegresar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnRegresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnRegresar.setBounds(423, 192, 112, 30);
		contentPane.add(btnRegresar);
		btnRegresar.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			 regresar();
		}
		
		private void regresar() {
			setVisible(false);
			
		}
	});
		
	}

}
