package direccion_finanzas;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import utils.MySQLConexion;

import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;

public class Contratos extends JFrame {
	private void eliminar() {
		 txtidcontrato.setText(null);
	      txtfecha.setText(null);
	      txtpatrocinador.setText(null);
	      txtvigencia.setText(null);
	      txtmaterial.setText(null);
	      txtransporte.setText(null);
	}
	private void limpiarcajas() {
		
		txtidcontrato.setText(null);
	      txtfecha.setText(null);
	      txtpatrocinador.setText(null);
	      txtvigencia.setText(null);
	      txtmaterial.setText(null);
	      txtransporte.setText(null);

	}
	
	public static Connection getconexion() {
		Connection con =null;
		

	    
	    try {
	        Class.forName("com.mysql.jdbc.Driver");
	      String url = "jdbc:mysql://localhost:3306/cartas_1";
	      String usr ="root";
	      String psw = "James1509";
	      
	      PreparedStatement ps;
	      ResultSet rs;
	      
	      con = DriverManager.getConnection(url,usr,psw);
	   

	    } catch (ClassNotFoundException e) {
	        System.out.println("Error al cargar el controlador");
	      

	    } catch (SQLException e) {
	        System.out.println("Error en la conexi�n a base de datos");
	    }
	    
	    return con;
	}



	private JPanel contentPane;
	private JTextField txtidcontrato;
	private JTextField txtfecha;
	private JTextField txtpatrocinador;
	private JTextField txtvigencia;
	private JTextField txtmaterial;
	private JTextField txtransporte;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Contratos frame = new Contratos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Contratos() {
		setTitle("Contratos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 555, 331);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtidcontrato = new JTextField();
		txtidcontrato.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtidcontrato.setBounds(116, 11, 131, 30);
		contentPane.add(txtidcontrato);
		txtidcontrato.setColumns(10);
		
		txtfecha = new JTextField();
		txtfecha.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtfecha.setBounds(411, 11, 118, 30);
		contentPane.add(txtfecha);
		txtfecha.setColumns(10);
		
		txtpatrocinador = new JTextField();
		txtpatrocinador.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtpatrocinador.setBounds(116, 83, 131, 30);
		contentPane.add(txtpatrocinador);
		txtpatrocinador.setColumns(10);
		
		txtvigencia = new JTextField();
		txtvigencia.setFont(new Font("Tw Cen MT Condensed", Font.PLAIN, 15));
		txtvigencia.setBounds(411, 83, 118, 30);
		contentPane.add(txtvigencia);
		txtvigencia.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Contrato");
		lblNewLabel.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel.setBounds(10, 14, 96, 27);
		contentPane.add(lblNewLabel);
		
		JLabel lblFecha = new JLabel("Fecha");
		lblFecha.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblFecha.setBounds(305, 14, 96, 27);
		contentPane.add(lblFecha);
		
		JLabel lblPatrocinador = new JLabel("Patrocinador");
		lblPatrocinador.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblPatrocinador.setBounds(10, 86, 96, 27);
		contentPane.add(lblPatrocinador);
		
		JLabel lblVigencia = new JLabel("Vigencia");
		lblVigencia.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblVigencia.setBounds(305, 83, 96, 27);
		contentPane.add(lblVigencia);
		
		JButton btnNewButton_1 = new JButton("Buscar");
		btnNewButton_1.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_1.setBounds(116, 221, 89, 23);
		btnNewButton_1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnNewButton_1.addActionListener(new ActionListener() {
			private PreparedStatement ps;
			private ResultSet rs;

			public void actionPerformed(ActionEvent e) {
				Connection con = null;
				
				try {
                   con = MySQLConexion.getconexion();
					
					
					ps= con.prepareStatement("SELECT * FROM contrato WHERE idcontrato =?");
					ps.setString(1,txtidcontrato.getText());
			      
			      
					
					rs = ps.executeQuery();
					
					if(rs.next()) {
						 txtidcontrato.setText(rs.getString("idcontrato"));
					      txtfecha.setText(rs.getString("fecha")); 
					      txtpatrocinador.setText(rs.getString("patrocinador"));
					      txtvigencia.setText(rs.getString("vigencia"));
					      txtmaterial.setText(rs.getString("material"));
					      txtransporte.setText(rs.getString("transporte"));
					     
					      
					}else {
						JOptionPane.showMessageDialog(null,"contrato no existente");
						
					}
			    	
				}catch(Exception e1) {

					System.err.println(e1);
				
				}
			}
		});

		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("Agregar");
		btnNewButton_1_1.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_1_1.setBounds(10, 220, 89, 24);
		btnNewButton_1_1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnNewButton_1_1.addActionListener(new ActionListener() {
			private Connection con;
			private PreparedStatement ps;
			
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				Connection con = null;
			
				try {
					
					con = MySQLConexion.getconexion();
					
					
					ps= con.prepareStatement("INSERT INTO contrato(idcontrato, fecha, patrocinador, vigencia, material, transporte) VALUES(?, ?, ?, ?, ?, ?)");
			        ps.setString(1,txtidcontrato.getText());
			        ps.setString(2,txtfecha.getText());
			        ps.setString(3,txtpatrocinador.getText());
			        ps.setString(4,txtvigencia.getText());
			        ps.setString(5,txtmaterial.getText());
			        ps.setString(6,txtransporte.getText());
			       
			    	
			     
					int rs = ps.executeUpdate();

					if (rs > 0) {
						JOptionPane.showMessageDialog(null,"contrato nuevo agregado ");
						eliminar();
					}else {
						JOptionPane.showMessageDialog(null,"error al introducir contrato nuevo");
						eliminar();
					}
					
					con.close();
					
				
				}catch(Exception e) {

					System.err.println(e);
				
				}
			}		
				
		});

		contentPane.add(btnNewButton_1_1);
		
		JButton btnNewButton_1_2 = new JButton("Limpiar");
		btnNewButton_1_2.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_1_2.setBounds(227, 220, 89, 24);
		btnNewButton_1_2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnNewButton_1_2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			
			  limpiarcajas();
		}
		
			
		});
		contentPane.add(btnNewButton_1_2);
		
		JButton btnNewButton_1_2_1 = new JButton("Regresar");
		btnNewButton_1_2_1.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_1_2_1.setBounds(440, 257, 89, 24);
		btnNewButton_1_2_1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnNewButton_1_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 regresar();
			}
			
			private void regresar() {
				setVisible(false);
				
			}
		});
		contentPane.add(btnNewButton_1_2_1);
		
		txtmaterial = new JTextField();
		txtmaterial.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtmaterial.setBounds(116, 136, 131, 30);
		contentPane.add(txtmaterial);
		txtmaterial.setColumns(10);
		
		JLabel lblMaterial = new JLabel("Material");
		lblMaterial.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblMaterial.setBounds(10, 137, 96, 27);
		contentPane.add(lblMaterial);
		
		JLabel lblTransporte = new JLabel("Transporte");
		lblTransporte.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblTransporte.setBounds(305, 137, 96, 27);
		contentPane.add(lblTransporte);
		
		txtransporte = new JTextField();
		txtransporte.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtransporte.setColumns(10);
		txtransporte.setBounds(411, 136, 118, 30);
		contentPane.add(txtransporte);
	}

}
