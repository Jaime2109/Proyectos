package direccion_finanzas;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Logistica.Logistica;
import Produccion.Almacen;

import recursos_humanos.EmpleadoNuevo;
import recursos_humanos.rrhh;

public class Departamentos extends JFrame implements ActionListener{

	/**
	 * 
	 */
	
	private JPanel contentPane;
	private ImageIcon image;
	private JLabel ImageLabel;
	private JPanel ImagePanel;
	private JComboBox comboBoxDepto;
	private JButton NewButton;
	private JButton Aceptar;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Departamentos frame = new  Departamentos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	
	public Departamentos() {
		
		
		setTitle("Departamentos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 894, 784);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Dialog", Font.PLAIN, 20));
		comboBoxDepto= new JComboBox (new String[] {"","Finanzas", "Logistica","Almacen", "Recursos Humanos"});
		comboBoxDepto.setSelectedIndex(0);
		final int comboboxObject = comboBoxDepto.getSelectedIndex();
		comboBoxDepto.setForeground(new Color(0, 51, 153));
		comboBoxDepto.setFont(new Font("Dialog", Font.PLAIN, 40));
		comboBoxDepto.setBounds(210, 427, 464, 162);
		contentPane.add(comboBoxDepto);
		
		
		//El texto  de Selecciona tu departamento
		JLabel Labeldpto = new JLabel("Selecciona tu departamento:");
		Labeldpto.setForeground(new Color(102, 153, 204));
		Labeldpto.setFont(new Font("Dialog", Font.BOLD, 23));
		Labeldpto.setBounds(275, 377, 326, 60);
		contentPane.add(Labeldpto);
	
		//
		ImagePanel = new JPanel();
		ImagePanel.setBounds(189, 11, 510, 355);
		ImagePanel.setBackground(Color.white);
		ImageLabel = new JLabel();
		image = new ImageIcon(getClass().getClassLoader().getResource("AutoPartes.jpg"));
		ImageLabel.setIcon(image);
		ImagePanel.add(ImageLabel);
		contentPane.add(ImagePanel);
		
		
	  Aceptar = new JButton();
		  try {
		    Image img = ImageIO.read(getClass().getClassLoader().getResource("acierto.png"));
		    Aceptar.setIcon(new ImageIcon(img));
		  } catch (Exception ex) {
		    System.out.println(ex);
		  }
		Aceptar.addActionListener(this);
		Aceptar.setBounds(372, 652, 125, 51);
		Aceptar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		contentPane.add(Aceptar);
	}
	
	public void actionPerformed(ActionEvent e) {
	      int selectedIndex = comboBoxDepto.getSelectedIndex();
	        switch (selectedIndex) {
	        /*case 0: //COMERCIAL
        	System.out.println("Comercial Aceptar");
        	p.setVisible(true);
        	break;*/
	        	
	        case 1: //FINANZAS
	        	System.out.println("Finanzas Seleccionado");
	        	
	        	Finanzas f = new Finanzas();
				f.setVisible(true);
				
	        	break;
	        	
	        /*case 2: //DIRECCION GENERAL
	        	System.out.println("Direccion General Seleccionado");
	        	
	        	Dgeneral frame = new Dgeneral();
	        	frame.setVisible(true);
	        	break;*/
	        
	        	
	        case 2: //LOGISTICA
	        	System.out.println("Logistica Seleccionado");
	        	Logistica frame1 = new Logistica();
				frame1.setVisible(true);
	        	break;
	        	
	        case 3: //PRODUCCION
	        	System.out.println("Almacen");
	        	Almacen frame2 = new Almacen();
				frame2.setVisible(true);
	        	break;
	        	
	        case 4: //RECURSOS HUMANOS
	        	System.out.println("Recursos Humanos");
	        	rrhh frame3 = new rrhh();
				frame3.setVisible(true);
		       	break;
		       	
	  /*  case 6:
	        	System.out.println("TI");
		       	break;*/
	        }
	
	    
	
	}
    private void MetodoIngresarusuario() {
		// TODO Auto-generated method stub
		
	}
    }
	