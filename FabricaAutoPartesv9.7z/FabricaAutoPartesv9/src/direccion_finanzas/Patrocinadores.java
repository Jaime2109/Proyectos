package direccion_finanzas;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import utils.MySQLConexion;

import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;

public class Patrocinadores extends JFrame {
	private void eliminar() {
		 txtidnombre.setText(null);
	      txtvigencia.setText(null);
	      txtpublicidad.setText(null);
	      txtmonto.setText(null);
	      
	}
	private void limpiarcajas() {
		
		 txtidnombre.setText(null);
	      txtvigencia.setText(null);
	      txtpublicidad.setText(null);
	      txtmonto.setText(null);
	      
	}
	
	public static Connection getconexion() {
		Connection con =null;
		

	    
	    try {
	        Class.forName("com.mysql.jdbc.Driver");
	      String url = "jdbc:mysql://localhost:3306/cartas_1";
	      String usr ="root";
	      String psw = "James1509";
	      
	      PreparedStatement ps;
	      ResultSet rs;
	      
	      con = DriverManager.getConnection(url,usr,psw);
	   

	    } catch (ClassNotFoundException e) {
	        System.out.println("Error al cargar el controlador");
	      

	    } catch (SQLException e) {
	        System.out.println("Error en la conexi�n a base de datos");
	    }
	    
	    return con;
	}



	private JPanel contentPane;
	private JTextField txtidnombre;
	private JTextField txtvigencia;
	private JTextField txtpublicidad;
	private JTextField txtmonto;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Patrocinadores frame = new Patrocinadores();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Patrocinadores() {
		setTitle("Patrocinadores");
		setBackground(SystemColor.activeCaption);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 559, 318);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtidnombre = new JTextField();
		txtidnombre.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtidnombre.setBounds(82, 103, 163, 34);
		contentPane.add(txtidnombre);
		txtidnombre.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Nombre");
		lblNewLabel.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel.setBounds(10, 104, 95, 31);
		contentPane.add(lblNewLabel);
		
		txtvigencia = new JTextField();
		txtvigencia.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtvigencia.setColumns(10);
		txtvigencia.setBounds(370, 103, 163, 34);
		contentPane.add(txtvigencia);
		
		JLabel lblVigencia = new JLabel("Vigencia");
		lblVigencia.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblVigencia.setBounds(255, 104, 95, 31);
		contentPane.add(lblVigencia);
		
		JLabel lblPublicidad = new JLabel("Publicidad");
		lblPublicidad.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblPublicidad.setBounds(10, 170, 73, 31);
		contentPane.add(lblPublicidad);
		
		txtpublicidad = new JTextField();
		txtpublicidad.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtpublicidad.setColumns(10);
		txtpublicidad.setBounds(82, 169, 163, 34);
		contentPane.add(txtpublicidad);
		
		txtmonto = new JTextField();
		txtmonto.setText("$");
		txtmonto.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		txtmonto.setColumns(10);
		txtmonto.setBounds(370, 169, 163, 34);
		contentPane.add(txtmonto);
		
		JLabel lblMonto = new JLabel("Monto");
		lblMonto.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblMonto.setBounds(265, 170, 95, 31);
		contentPane.add(lblMonto);
		
		JButton btnNewButton_1 = new JButton("Buscar");
		btnNewButton_1.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_1.setBounds(10, 225, 117, 23);
		btnNewButton_1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnNewButton_1.addActionListener(new ActionListener() {
			private PreparedStatement ps;
			private ResultSet rs;

			public void actionPerformed(ActionEvent e) {
				Connection con = null;
				
				try {
                   con = MySQLConexion.getconexion();
					
					
					ps= con.prepareStatement("SELECT * FROM patrocinador WHERE idnombre =?");
					ps.setString(1,txtidnombre.getText());
			      
			      
					
					rs = ps.executeQuery();
					
					if(rs.next()) {
						 txtidnombre.setText(rs.getString("idnombre"));
					      txtvigencia.setText(rs.getString("vigencia")); 
					      txtpublicidad.setText(rs.getString("publicidad"));
					      txtmonto.setText(rs.getString("monto"));
					      
					     
					      
					}else {
						JOptionPane.showMessageDialog(null,"patrocinador no existente");
						
					}
			    	
				}catch(Exception e1) {

					System.err.println(e1);
				
				}
			}
		});
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("Limpiar");
		btnNewButton_1_1.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_1_1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnNewButton_1_1.setBounds(218, 225, 117, 23);
		btnNewButton_1_1.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				  limpiarcajas();
			}
			
				
			});
		contentPane.add(btnNewButton_1_1);
		
		JButton btnNewButton = new JButton("Regresar");
		btnNewButton.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnNewButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnNewButton.setBounds(416, 225, 117, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 regresar();
			}
			
			private void regresar() {
				setVisible(false);
				
			}
		});
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\jaime\\Desktop\\FabricaAutoPartesv8\\res\\Logov.jpg"));
		lblNewLabel_1.setBounds(93, 12, 196, 81);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\jaime\\Desktop\\FabricaAutoPartesv8\\res\\acierto.png"));
		lblNewLabel_2.setBounds(404, 12, 129, 80);
		contentPane.add(lblNewLabel_2);
	}

}
