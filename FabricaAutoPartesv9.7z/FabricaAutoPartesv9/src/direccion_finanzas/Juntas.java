package direccion_finanzas;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import utils.MySQLConexion;

import javax.swing.JEditorPane;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Juntas extends JFrame {

	private void eliminar() {
		 txtidjuntas.setText(null);
	      txtfecha.setText(null);
	      txtpatrocinador.setText(null);
	    
	      
		
	}
	public static Connection getconexion() {
	Connection con =null;

   
   try {
       Class.forName("com.mysql.jdbc.Driver");
     String url = "jdbc:mysql://localhost:3306/cartas_1";
     String usr ="root";
     String psw = "James1509";
     
     PreparedStatement ps;
     ResultSet rs;
     
     con = DriverManager.getConnection(url,usr,psw);
  

   } catch (ClassNotFoundException e) {
       System.out.println("Error al cargar el controlador");
     

   } catch (SQLException e) {
       System.out.println("Error en la conexi�n a base de datos");
   }
   
   return con;
}

private void limpiarcajas() {
	
	txtidjuntas.setText(null);
    txtfecha.setText(null);
    txtpatrocinador.setText(null);
  
	
}
	

	private JPanel contentPane;
	private JTextField txtidjuntas;
	private JTextField txtfecha;
	private JTextField txtpatrocinador;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Juntas frame = new Juntas();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Juntas() {
		setTitle("Juntas");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 560, 333);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JEditorPane dtrpnBuscarJuntas = new JEditorPane();
		dtrpnBuscarJuntas.setText("Buscar Juntas:\r\n\r\n1020         9090\r\n1021         8090\r\n3030         1010\r\n3023         1515\r\n2303         0002");
		dtrpnBuscarJuntas.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		dtrpnBuscarJuntas.setBounds(292, 11, 242, 239);
		contentPane.add(dtrpnBuscarJuntas);
		
		txtidjuntas = new JTextField();
		txtidjuntas.setBounds(109, 63, 173, 23);
		contentPane.add(txtidjuntas);
		txtidjuntas.setColumns(10);
		
		txtfecha = new JTextField();
		txtfecha.setBounds(109, 136, 173, 23);
		contentPane.add(txtfecha);
		txtfecha.setColumns(10);
		
		txtpatrocinador = new JTextField();
		txtpatrocinador.setBounds(109, 208, 173, 23);
		contentPane.add(txtpatrocinador);
		txtpatrocinador.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Codigo");
		lblNewLabel.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel.setBounds(10, 55, 95, 37);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Fecha");
		lblNewLabel_1.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1.setBounds(10, 131, 84, 31);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Patrocinador");
		lblNewLabel_2.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_2.setBounds(10, 205, 84, 26);
		contentPane.add(lblNewLabel_2);
		
		JButton buscar = new JButton("Buscar");
		buscar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		buscar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		buscar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		buscar.addActionListener(new ActionListener() {
			
			private PreparedStatement ps;
			private ResultSet rs;

			
			public void actionPerformed(ActionEvent e) {
				Connection con = null;
				try {
                    con = MySQLConexion.getconexion();
					
					
					ps= con.prepareStatement("SELECT * FROM juntas WHERE idjuntas=?");
					ps.setString(1,txtidjuntas.getText());
			      
			      
					
					rs = ps.executeQuery();
					
					if(rs.next()) {
						 txtidjuntas.setText(rs.getString("idjuntas"));
					      txtfecha.setText(rs.getString("fecha")); 
					      txtpatrocinador.setText(rs.getString("patrocinador"));
					     
					     
					     
					      
					
			    	
				}else {
					JOptionPane.showMessageDialog(null,"junta no existente");
					limpiarcajas();
				}
		    	
			}catch(Exception e1) {

				System.err.println(e1);
			
			}
		}
	});
		buscar.setBounds(10, 260, 89, 23);
		contentPane.add(buscar);
		
		JButton btnLimpiar = new JButton("Limpiar");
		btnLimpiar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnLimpiar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnLimpiar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnLimpiar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				  limpiarcajas();
			}
			
				
					    	
		});
		
		btnLimpiar.setBounds(159, 260, 89, 23);
		contentPane.add(btnLimpiar);
		
		JButton btnEliminar = new JButton("Eliminar");
		btnEliminar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnEliminar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnEliminar.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnEliminar.addActionListener(new ActionListener() {
			private PreparedStatement ps;

			public void actionPerformed(ActionEvent arg0) {
				Connection con = null;
				
				try {
					
					con = MySQLConexion.getconexion();
					
					
					ps= con.prepareStatement("DELETE FROM juntas WHERE idjuntas=?");
			        ps.setInt(1, Integer.parseInt(txtidjuntas.getText()));
			        
			    	
					int rs = ps.executeUpdate();

					if (rs > 0) {
						JOptionPane.showMessageDialog(null,"junta eliminada ");
						eliminar();
					}else {
						JOptionPane.showMessageDialog(null,"error al eliminar junta ");
						eliminar();
					}
					
					con.close();
					
				
				}catch(Exception e) {

					System.err.println(e);
				
				}
			}		
			
		});
		btnEliminar.setBounds(292, 260, 89, 23);
		contentPane.add(btnEliminar);
		
		JButton btnNewButton = new JButton("Regresar");
		btnNewButton.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		btnNewButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 regresar();
			}
			
			private void regresar() {
				setVisible(false);
				
			}
		});
		btnNewButton.setBounds(445, 261, 89, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_3 = new JLabel("Agendar Proximas Juntas");
		lblNewLabel_3.setFont(new Font("Tw Cen MT Condensed", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_3.setBounds(10, 11, 272, 31);
		contentPane.add(lblNewLabel_3);
	}
}
