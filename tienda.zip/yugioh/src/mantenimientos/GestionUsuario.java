package mantenimientos;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;
import clases.usuario;
import utils.MySQLConexion;



	
	public class GestionUsuario {
		

		public usuario obtenerUsuario(usuario usu){
			
			usuario usuario = null;
			
			Connection con = null;
			PreparedStatement pst = null;
			ResultSet rs = null;
			
			try {
			
				con = MySQLConexion.getconexion();
			
				String sql = "select*from login where usuarios = ? and Contrase�a =  ? ";
				
				pst = con.prepareStatement(sql);
				
				pst.setString(1, usu.getusuarios());
				pst.setString(2, usu.getContrase�a());
				
				rs = pst.executeQuery();
				
				while (rs.next()) {
					usuario = new usuario(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
					
				}
				
				
				
			} catch (Exception e) {
			System.out.println("Error en obtener usuario");
			}
			
			
			return usuario;
			
		}
			

		}
