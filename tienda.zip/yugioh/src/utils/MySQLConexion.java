package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MySQLConexion {
	public static Connection getconexion() {
		Connection con =null;

		        
		        try {
		            Class.forName("com.mysql.jdbc.Driver");
		          String url = "jdbc:mysql://localhost:3306/cartas_1";
		          String usr ="root";
		          String psw = "James1509";
		          
		          con = DriverManager.getConnection(url,usr,psw);
		       

		        } catch (ClassNotFoundException e) {
		            System.out.println("Error al cargar el controlador");
		          

		        } catch (SQLException e) {
		            System.out.println("Error en la conexi�n a base de datos");
		        }
		        
		        return con;
		    }

		

		}




