package formulario;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;

import java.awt.event.ActionEvent;

import hilos.HiloBarra;
import utils.MySQLConexion;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import javax.swing.border.CompoundBorder;
import javax.swing.border.BevelBorder;
import java.awt.SystemColor;
import javax.swing.JProgressBar;
import java.awt.Label;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent ;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JEditorPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextArea;

public class CATALOGO extends JFrame {
	
	private void eliminar() {
		 txtidproducto.setText(null);
	      txtnombre.setText(null);
	      txtunidad.setText(null);
	      txtcantidad.setText(null);
	      txtprecio.setText(null);
		
	}
	public static Connection getconexion() {
	Connection con =null;

    
    try {
        Class.forName("com.mysql.jdbc.Driver");
      String url = "jdbc:mysql://localhost:3306/cartas_1";
      String usr ="root";
      String psw = "James1509";
      
      PreparedStatement ps;
      ResultSet rs;
      
      con = DriverManager.getConnection(url,usr,psw);
   

    } catch (ClassNotFoundException e) {
        System.out.println("Error al cargar el controlador");
      

    } catch (SQLException e) {
        System.out.println("Error en la conexi�n a base de datos");
    }
    
    return con;
}


	private JPanel contentPane;
	private JTextField txtunidad;
	private JTextField txtnombre;
	private JTextField txtprecio;
	private JTextField txtcantidad;
	private JTextField txtidproducto;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CATALOGO frame = new CATALOGO();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CATALOGO() {
		setTitle("BIENVENIDO A \tTIENDA LOS TRES PATITOS");
		setIconImage(Toolkit.getDefaultToolkit().getImage(CATALOGO.class.getResource("/com/sun/javafx/scene/control/skin/modena/dialog-information.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 765, 333);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtidproducto = new JTextField();
		txtidproducto.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		txtidproducto.setBackground(SystemColor.inactiveCaptionBorder);
		txtidproducto.addKeyListener(new KeyAdapter() {
			
		

			public void keyTyped(java.awt.event.KeyEvent evt) {
				
				char c = evt.getKeyChar();
				
				if(c<'0' || c>'9') evt.consume();
			}
		});
		txtidproducto.setBounds(215, 49, 86, 20);
		contentPane.add(txtidproducto);
		txtidproducto.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("ID:");
		lblNewLabel.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setBounds(215, 24, 30, 14);
		contentPane.add(lblNewLabel);
		
		txtunidad = new JTextField();
		txtunidad.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		txtunidad.setBackground(SystemColor.inactiveCaptionBorder);
		txtunidad.setBounds(516, 49, 153, 20);
		contentPane.add(txtunidad);
		txtunidad.setColumns(10);
		
		txtnombre = new JTextField();
		txtnombre.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		txtnombre.setBackground(SystemColor.inactiveCaptionBorder);
		txtnombre.setBounds(340, 49, 153, 20);
		contentPane.add(txtnombre);
		txtnombre.setColumns(10);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(224, 255, 255));
		panel.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null), null));
		panel.setBounds(0, 0, 204, 564);
		contentPane.add(panel);
		panel.setLayout(null);
		
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {" ID LACTEOS:", "11 leche alpura ", " 12 leche alpura ", " 13 leche lala", "  14 leche lala", " 15 leche santa clara", " 16 leche santa clara", "17 yogurt lala ", " 18 yogurt lala", " 19 yogurt alpura", " 20 yogurt alpura", " 21 yogurt activia ", " 22 yogurt griego"}));
		comboBox_1.setBounds(10, 29, 184, 20);
		panel.add(comboBox_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		comboBox.setBounds(9, 73, 185, 20);
		panel.add(comboBox);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"ID ENLATADOS:", "1 atun aceite", "2 atun agua ", "3 sardina", "4 sardina adobada", "5 leche nido ", "6 leche nido ", "7 chiles rajas ", "8chiles rajas", "9 chiles chipotle", "10chiles chipotle"}));
		
		Label label = new Label("LISTA DE PRODUCTOS:");
		label.setFont(new Font("Malgun Gothic", Font.BOLD | Font.ITALIC, 14));
		label.setBounds(10, 7, 165, 16);
		panel.add(label);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"ID EMBOTELLADOS:", "23 coca cola ", "24 coca cola", "25 coca cola", "26 coca cola vidrio", "27 jarrito ", "28 jarrito ", "29 jarrito ", "30 refresco mundet", "31 refresco mundet"}));
		comboBox_2.setBounds(10, 118, 184, 20);
		panel.add(comboBox_2);
		
		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		comboBox_3.setModel(new DefaultComboBoxModel(new String[] {"ID ESPECIAS/ CHOCOLATES:", "4000 sal ", "4001 cafe ", "4002 azucar", "4003 pimienta", "4004 bicarbonato ", "4005 piloncillo\t", "4006 anis", "4007 chile piquin", "4008 chile de arbol", "4009 especia clavo", "5000 carlos v ", "5001 crunch ", "5002 milky way ", "5003 snickers", "5004 chocolate abuelita", "5005 coronado", "5006 huevo kinder ", "5007 kinder delice ", "5008 chocolate larin", "5009 chocolate turin"}));
		comboBox_3.setBounds(10, 159, 184, 20);
		panel.add(comboBox_3);
		
		JButton salir = new JButton("SALIR");
		salir.setBounds(10, 262, 135, 23);
		panel.add(salir);
		salir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				salir();
			}
		});
		salir.setBackground(SystemColor.activeCaption);
		salir.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 12));
		salir.setIcon(new ImageIcon(CATALOGO.class.getResource("/com/sun/java/swing/plaf/windows/icons/Error.gif")));
		
		txtprecio = new JTextField();
		txtprecio.setText("$");
		txtprecio.setBackground(SystemColor.inactiveCaptionBorder);
		txtprecio.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(java.awt.event.KeyEvent evt) {

				double a = evt.getKeyChar();
				
				if(a<'0' || a>'9') evt.consume();
				
			}
		});
		txtprecio.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		txtprecio.setBounds(516, 107, 153, 20);
		contentPane.add(txtprecio);
		txtprecio.setColumns(10);
		
		txtcantidad = new JTextField();
		txtcantidad.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		txtcantidad.setBackground(SystemColor.inactiveCaptionBorder);
		txtcantidad.addKeyListener(new KeyAdapter() {
			
			public void keyTyped(java.awt.event.KeyEvent evt) {

				char b = evt.getKeyChar();
				
				if(b<'0' || b>'9') evt.consume();
			}
		});
		txtcantidad.setBounds(340, 107, 153, 20);
		contentPane.add(txtcantidad);
		txtcantidad.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("NOMBRE DEL PRODUCTO:");
		lblNewLabel_2.setToolTipText("");
		lblNewLabel_2.setBounds(340, 24, 153, 14);
		contentPane.add(lblNewLabel_2);
		lblNewLabel_2.setForeground(Color.BLACK);
		lblNewLabel_2.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		
		JLabel lblNewLabel_1 = new JLabel("CANTIDAD:");
		lblNewLabel_1.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_1.setBounds(340, 80, 153, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_3 = new JLabel("UNIDAD:");
		lblNewLabel_3.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_3.setBounds(516, 24, 153, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("PRECIO:");
		lblNewLabel_4.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_4.setBounds(516, 80, 153, 14);
		contentPane.add(lblNewLabel_4);
		
		JButton buscar = new JButton("BUSCAR");
		buscar.setIcon(new ImageIcon(CATALOGO.class.getResource("/com/sun/javafx/scene/web/skin/Bold_16x16_JFX.png")));
		buscar.setBounds(215, 174, 138, 23);
		contentPane.add(buscar);
		buscar.addActionListener(new ActionListener() {
			private PreparedStatement ps;
			private ResultSet rs;

			public void actionPerformed(ActionEvent e) {
				Connection con = null;
				
				try {
                    con = MySQLConexion.getconexion();
					
					
					ps= con.prepareStatement("SELECT * FROM tienda WHERE idtienda =?");
					ps.setString(1,txtidproducto.getText());
			      
			      
					
					rs = ps.executeQuery();
					
					if(rs.next()) {
						 txtidproducto.setText(rs.getString("idtienda"));
					      txtnombre.setText(rs.getString("producto")); 
					      txtunidad.setText(rs.getString("unidad"));
					      txtcantidad.setText(rs.getString("cantidad"));
					      txtprecio.setText(rs.getString("precio"));
					     
					      
					}else {
						JOptionPane.showMessageDialog(null,"producto no existente");
						
					}
			    	
				}catch(Exception e1) {

					System.err.println(e1);
				
				}
			}
		});
		buscar.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		buscar.setBackground(SystemColor.activeCaption);
		
		JButton agregar = new JButton("AGREGAR");
		agregar.setIcon(new ImageIcon(CATALOGO.class.getResource("/javax/swing/plaf/metal/icons/ocean/floppy.gif")));
		agregar.setBounds(372, 174, 138, 23);
		contentPane.add(agregar);
		agregar.addActionListener(new ActionListener() {
			private Connection con;
			private PreparedStatement ps;
			
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				Connection con = null;
			
				try {
					
					con = MySQLConexion.getconexion();
					
					
					ps= con.prepareStatement("INSERT INTO tienda(idtienda, producto, unidad,cantidad, precio ) VALUES(?, ?, ?, ?, ?)");
			        ps.setString(1,txtidproducto.getText());
			        ps.setString(2,txtnombre.getText());
			        ps.setString(4,txtcantidad.getText());
			        ps.setString(5,txtprecio.getText());
			        ps.setString(3,txtunidad.getText());
			       
			    	
			     
					int rs = ps.executeUpdate();

					if (rs > 0) {
						JOptionPane.showMessageDialog(null,"producto nuevo agregado ");
						eliminar();
					}else {
						JOptionPane.showMessageDialog(null,"error al introducir produto nuevo");
						eliminar();
					}
					
					con.close();
					
				
				}catch(Exception e) {

					System.err.println(e);
				
				}
			}		
				
		});
		agregar.setToolTipText("");
		agregar.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 12));
		agregar.setBackground(SystemColor.activeCaption);
		agregar.setForeground(Color.BLACK);
		
		JButton eliminar = new JButton("ELIMINAR");
		eliminar.setIcon(new ImageIcon(CATALOGO.class.getResource("/javax/swing/plaf/metal/icons/ocean/warning.png")));
		eliminar.setBounds(531, 174, 138, 23);
		contentPane.add(eliminar);
		eliminar.addActionListener(new ActionListener() {
			private PreparedStatement ps;

			public void actionPerformed(ActionEvent arg0) {
				Connection con = null;
				
				try {
					
					con = MySQLConexion.getconexion();
					
					
					ps= con.prepareStatement("DELETE FROM tienda WHERE idtienda=?");
			        ps.setInt(1, Integer.parseInt(txtidproducto.getText()));
			        
			    	
					int rs = ps.executeUpdate();

					if (rs > 0) {
						JOptionPane.showMessageDialog(null,"producto eliminada ");
						eliminar();
					}else {
						JOptionPane.showMessageDialog(null,"error al eliminar producto ");
						eliminar();
					}
					
					con.close();
					
				
				}catch(Exception e) {

					System.err.println(e);
				
				}
			}		
			
		});
		eliminar.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		eliminar.setBackground(SystemColor.activeCaption);
		
		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setIcon(new ImageIcon("C:\\Users\\jaime\\Pictures\\WhatsApp Image 2020-05-07 at 1.57.50 PM.jpeg"));
		lblNewLabel_5.setBounds(203, 0, 546, 294);
		contentPane.add(lblNewLabel_5);

	}
	
	protected void salir() {
		System.exit(0);
}
}
