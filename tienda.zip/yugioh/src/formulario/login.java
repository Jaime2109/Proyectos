package formulario;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import clases.usuario;
import hilos.HiloBarra;
import mantenimientos.GestionUsuario;
import utils.MySQLConexion;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Toolkit;
import javax.swing.JProgressBar;
import javax.swing.event.ChangeListener;

import com.mysql.jdbc.Connection;

import javax.swing.event.ChangeEvent;
import java.awt.SystemColor;

public class login extends JFrame {

	private JPanel contentPane;
	private JTextField txtusuarios;
	private JPasswordField txtContrase�a;
	public static JProgressBar cargar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login frame = new login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public login() {
		setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 12));
		setForeground(Color.PINK);
		setBackground(Color.WHITE);
		setTitle("INICIO DE SECION");
		setIconImage(Toolkit.getDefaultToolkit().getImage(login.class.getResource("/com/sun/javafx/scene/control/skin/caspian/dialog-information@2x.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 647, 394);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		cargar = new JProgressBar();
		cargar.setForeground(new Color(0, 191, 255));
		cargar.setStringPainted(true);
		cargar.setToolTipText("");
		cargar.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		cargar.setBackground(Color.WHITE);
		cargar.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				cargar();
			}

			private void cargar() {
				if(cargar.getValue()==100) {
				   CATALOGO CATALOGO = new CATALOGO();
				   CATALOGO.setVisible(true);
				   CATALOGO.setLocationRelativeTo(null);
					
					this.dispose();
					
					JOptionPane.showMessageDialog(rootPane,"Bienvenido");
					
				}
				
			}

			private void dispose() {
				// TODO Auto-generated method stub
				
			}
		});
		
		
		
		JButton registrar = new JButton("INGRESAR");
		registrar.setForeground(SystemColor.windowText);
		registrar.setBackground(SystemColor.activeCaption);
		registrar.setIcon(new ImageIcon(login.class.getResource("/com/sun/javafx/scene/control/skin/caspian/images/capslock-icon.png")));
		registrar.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		registrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				registrar();
			}
		});
		
		JButton salir = new JButton("SALIR");
		salir.setForeground(SystemColor.windowText);
		salir.setBackground(SystemColor.activeCaption);
		salir.setIcon(new ImageIcon(login.class.getResource("/javax/swing/plaf/metal/icons/Error.gif")));
		salir.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		salir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				salir();
			}
		});
		salir.setBounds(24, 321, 153, 23);
		contentPane.add(salir);
		registrar.setBounds(24, 266, 153, 23);
		contentPane.add(registrar);
		
		
		
		txtContrase�a = new JPasswordField();
		txtContrase�a.setBackground(SystemColor.activeCaption);
		txtContrase�a.setFont(new Font("Tw Cen MT", Font.PLAIN, 14));
		txtContrase�a.setBounds(24, 209, 160, 20);
		contentPane.add(txtContrase�a);
		
		txtusuarios = new JTextField();
		txtusuarios.setBackground(SystemColor.activeCaption);
		txtusuarios.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		txtusuarios.setBounds(24, 97, 160, 20);
		contentPane.add(txtusuarios);
		txtusuarios.setColumns(10);
		cargar.setBounds(0, 11, 606, 14);
		contentPane.add(cargar);
		
		JLabel lblNewLabel = new JLabel("USUARIO:");
		lblNewLabel.setIcon(new ImageIcon(login.class.getResource("/com/sun/java/swing/plaf/windows/icons/Computer.gif")));
		lblNewLabel.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel.setBounds(24, 55, 102, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("PASSWORD:");
		lblNewLabel_1.setIcon(new ImageIcon(login.class.getResource("/javax/swing/plaf/metal/icons/ocean/expanded.gif")));
		lblNewLabel_1.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_1.setBounds(10, 159, 102, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBackground(Color.WHITE);
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\jaime\\Pictures\\WhatsApp Image 2020-05-07 at 1.56.34 PM.jpeg"));
		lblNewLabel_2.setBounds(0, 0, 631, 355);
		contentPane.add(lblNewLabel_2);
		
		
	}
		
	protected void registrar() {

		String usuario = txtusuarios.getText();
		String Contrase�a = String.valueOf(txtContrase�a.getPassword());

		GestionUsuario gestionUsuario = new GestionUsuario();

		usuario usuario2 = new usuario();
		usuario2.setusuarios(usuario);
		usuario2.setContrase�a(Contrase�a);

		usuario usu = gestionUsuario.obtenerUsuario(usuario2);

		if (usu != null) {
			
	
			
			HiloBarra barra = new HiloBarra();
			barra.start();
			
			
		} else {
			JOptionPane.showMessageDialog(contentPane, "Datos invalidos", "Error", JOptionPane.ERROR_MESSAGE);
		}

	}

	protected void salir() {
		System.exit(0);
	}
}