package hilos;

import formulario.login;

public class HiloBarra extends Thread {
	
	public void run() {
		for(int i=0;i<=100;i++) {
			login.cargar.setValue(i);
			
			try {
				
				Thread.sleep(50);
			}catch(InterruptedException e) {
				e.printStackTrace();
			}
			
		}
	}

}
