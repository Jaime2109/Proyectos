package clases;


public class usuario {
	private String usuarios;
	private String Contrase�a;
	private String Nombre;
	
	 private String Carta;
	public usuario(String usuarios, String nombre, String contrase�a, String carta) {
		
		this.usuarios = usuarios;
		this.Contrase�a = contrase�a;
		this.Nombre = nombre;
		
		this.Carta = carta;
	}
	public usuario() {
		
	}
	public String getusuarios() {
		return usuarios;
	}
	public void setusuarios(String usuarios) {
		this.usuarios = usuarios;
	}
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public String getContrase�a() {
		return Contrase�a;
	}
	public void setContrase�a(String contrase�a) {
		Contrase�a = contrase�a;
	}
	public String getCarta() {
		return Carta;
	}
	public void setCarta(String carta) {
		Carta = carta;
	}
	 
	 
	 
}
		